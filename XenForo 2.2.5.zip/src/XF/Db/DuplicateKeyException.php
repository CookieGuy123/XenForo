<?php

namespace XF\Db;

class DuplicateKeyException extends \XF\Db\Exception
{
}