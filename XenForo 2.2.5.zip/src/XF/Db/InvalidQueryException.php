<?php

namespace XF\Db;

class InvalidQueryException extends \XF\Db\Exception
{
}