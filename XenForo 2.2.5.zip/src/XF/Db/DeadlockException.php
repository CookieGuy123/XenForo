<?php

namespace XF\Db;

class DeadlockException extends \XF\Db\Exception
{
}