<?php

namespace XenSoluce\AvatarGallery\Admin\Controller;

use XF\Admin\Controller\AbstractController;
use XF\Mvc\ParameterBag;
use XenSoluce\AvatarGallery\Entity\XsAvatarGallery;

class AvatarGallery extends AbstractController
{

    public function actionIndex()
    {
        $AvatarGallery = $this->finder('XenSoluce\AvatarGallery:XsAvatarGallery')->fetch();
        $viewParams = [
            'AvatarGallerys' => $AvatarGallery,
            'UserGroups' => $this->em()->getRepository('XF:UserGroup')->getUserGroupTitlePairs()
        ];

        return $this->view('', 'xs_ag_view', $viewParams);
    }
    public function AvatarGalleryAddEdit(XsAvatarGallery $XsAvatarGallery)
    {
        $files = \XF::app()->fs()->listContents('data://gallery_avatars', true);
        $categorys = [];
        foreach($files as $file) {
            if($file['type'] == 'dir'){
                $categorys[] = $file['filename'];
            }
        }
        $viewParams = [
            'AvatarGallery' => $XsAvatarGallery,
            'Categorys' => $categorys,
            'UserGroups' => $this->em()->getRepository('XF:UserGroup')->getUserGroupTitlePairs()
        ];

        return $this->view('', 'xs_ag_edit', $viewParams);
    }

    public function actionAdd()
    {
        $XsAvatarGallery = $this->em()->create('XenSoluce\AvatarGallery:XsAvatarGallery');

        return $this->AvatarGalleryAddEdit($XsAvatarGallery);
    }
    public function actionEdit(ParameterBag $params)
    {
        $XsAvatarGallery = $this->assertAvatarGalleryExists($params['avatar_gallery_id']);

        return $this->AvatarGalleryAddEdit($XsAvatarGallery);
    }
    protected function AvatarGallerySaveProcess(XsAvatarGallery $XsAvatarGallery)
    {
        $entityInput = $this->filter([
            'title_category' => 'str',
            'permission_category' => 'array',
        ]);

        $form = $this->formAction();
        $form->basicEntitySave($XsAvatarGallery, $entityInput);

        return $form;
    }
    public function actionSave(ParameterBag $params)
    {
        $this->assertPostOnly();
        $AG = $this->finder('XenSoluce\AvatarGallery:XsAvatarGallery')->where('title_category', $this->filter('title_category', 'str'))->fetchOne();

        if ($params['avatar_gallery_id'])
        {
            $XsAvatarGallery = $this->assertAvatarGalleryExists($params['avatar_gallery_id']);
        }
        elseif($AG){
            $XsAvatarGallery = $this->assertAvatarGalleryExists($AG->avatar_gallery_id);
        }
        else
        {
            $XsAvatarGallery = $this->em()->create('XenSoluce\AvatarGallery:XsAvatarGallery');
        }

        $this->AvatarGallerySaveProcess($XsAvatarGallery)->run();

        return $this->redirect($this->buildLink('avatar-gallery'));
    }
    public function actionDelete(ParameterBag $params)
    {
        $XsAvatarGallery = $this->assertAvatarGalleryExists($params['avatar_gallery_id']);
        if ($this->isPost())
        {
            $XsAvatarGallery->delete();

            return $this->redirect($this->buildLink('avatar-gallery'));
        }
        else
        {
            $viewParams = [
                'AvatarGallery' => $XsAvatarGallery
            ];

            return $this->view('', 'xs_ag_delete', $viewParams);
        }
    }
    protected function assertAvatarGalleryExists($id, $with = null, $phraseKey = null)
    {
        return $this->assertRecordExists('XenSoluce\AvatarGallery:XsAvatarGallery', $id, $with, $phraseKey);
    }
}