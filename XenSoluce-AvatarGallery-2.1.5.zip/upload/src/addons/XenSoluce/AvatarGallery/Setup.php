<?php

namespace XenSoluce\AvatarGallery;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Create;
use XF\Db\SchemaManager;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;

    public function installStep1()
    {
        $sm = $this->schemaManager();

        $sm->createTable('xf_xs_avatar_gallery', function (Create $table)
        {
            $table->addColumn('avatar_gallery_id', 'int')->autoIncrement();
            $table->addColumn('title_category', 'varchar', 255);
            $table->addColumn('permission_category', 'varbinary', 255);
            $table->addPrimaryKey('avatar_gallery_id');
        });
    }
    public function upgrade2010020Step1()
    {
        $sm = $this->schemaManager();

        $sm->createTable('xf_xs_avatar_gallery', function (Create $table)
        {
            $table->addColumn('avatar_gallery_id', 'int')->autoIncrement();
            $table->addColumn('title_category', 'varchar', 255);
            $table->addColumn('permission_category', 'varbinary', 255);
            $table->addPrimaryKey('avatar_gallery_id');
        });
    }

    public function uninstallStep1(array $stepParams = [])
    {
        $sm = $this->schemaManager();
        $sm->dropTable('xf_xs_avatar_gallery');
    }
}