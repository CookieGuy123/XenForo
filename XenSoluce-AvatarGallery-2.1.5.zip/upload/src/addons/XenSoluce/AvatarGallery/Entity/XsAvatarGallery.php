<?php

namespace XenSoluce\AvatarGallery\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class XsAvatarGallery extends Entity
{
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'xf_xs_avatar_gallery';
		$structure->shortName = 'XenSoluce\AvatarGallery:XsAvatarGallery';
		$structure->primaryKey = 'avatar_gallery_id';
		$structure->columns = [
			'avatar_gallery_id' => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'title_category' => ['type' => self::STR, 'maxLength' => 255, 'required' => true],
			'permission_category' => ['type' => self::LIST_COMMA, 'default' => []]
		];

		return $structure;
	}
}
