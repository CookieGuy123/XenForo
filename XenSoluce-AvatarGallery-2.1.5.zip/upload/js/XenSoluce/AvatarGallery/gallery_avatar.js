!function($, window, document, _undefined)
{
    "use strict";

    XF.XSgalleryavatar = XF.Click.newHandler({
        eventNameSpace: 'XSgalleryavatar',

        init: function() {},

        click: function(e)
        {
            e.preventDefault();

            $('#xs_ag_avatar_choice').val($(e.currentTarget).data('avatar-data-path'));

            if ($(e.currentTarget).hasClass('checked'))
            {
                $('#xs_ag_avatar_choice').val('');
                $('div#xs_ag_avatar_select').removeClass('checked');
            }
            else
            {
                $('div#xs_ag_avatar_select').removeClass('checked');
                $(e.currentTarget).addClass('checked');
            }
        }
    });

    XF.Click.register('xs_ag_avatar', 'XF.XSgalleryavatar');
}
(jQuery, window, document);
