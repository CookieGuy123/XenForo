<?php

namespace XENTR\ReputationSystem;

class MacroRender
{
    public static function preRender(\XF\Template\Templater $templater, &$type, &$template, &$name, array &$arguments, array &$globalVars)
    {
        if ($arguments['group']->group_id == 'XTRReputation')
        {
            $template = 'Reputation_macros';
        }
    }
}