<?php

namespace Andrew\ModeratorPanel;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

use XF\Db\Schema\Create;
use XF\Db\Schema\Alter;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;



    public function installStep1()
    {
        $this->schemaManager()->createTable('xf_andrew_mp_user_note', function(Create $table)
        {
            $table->addColumn('note_id', 'int')->autoIncrement();
            $table->addColumn('note_user_id', 'int')->nullable(true)->setDefault(null);
            $table->addColumn('user_id', 'int')->nullable(true)->setDefault(null);
            $table->addColumn('username','varchar', 250)->nullable(true)->setDefault(null);
            $table->addColumn('create_date', 'int',10)->nullable(true)->setDefault(\XF::$time);
            $table->addColumn('message', 'mediumtext')->nullable(true)->setDefault(null);

            $table->addPrimaryKey('note_id');
        });
    }

    public function upgrade1020270Step1()
    {

            $sm = $this->schemaManager();
            $sm->CreateTable('xf_andrew_mp_user_note', function (Create $table)
            {

                $table->addColumn('note_id', 'int')->autoIncrement();
                $table->addColumn('note_user_id', 'int')->nullable(true)->setDefault(null);
                $table->addColumn('user_id', 'int')->nullable(true)->setDefault(null);
                $table->addColumn('username','varchar', 250)->nullable(true)->setDefault(null);
                $table->addColumn('create_date', 'int',10)->nullable(true)->setDefault(\XF::$time);
                $table->addColumn('message', 'mediumtext')->nullable(true)->setDefault(null);

                $table->addPrimaryKey('note_id');

            });
    }

    public function uninstallStep1()
    {
        $this->schemaManager()->dropTable('xf_andrew_mp_user_note');
    }
}