<?php

namespace Andrew\ModeratorPanel\Entity;

use XF\Mvc\Entity\Structure;

class UserNote extends \XF\Mvc\Entity\Entity
{

    protected function _postDelete()
    {
        if ($this->getOption('log_moderator'))
        {
            $this->app()->logger()->logModeratorAction('user_note', $this, 'delete_hard');
        }
    }

    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_andrew_mp_user_note';
        $structure->shortName = 'Andrew\ModeratorPanel:UserNote';
        $structure->primaryKey = 'note_id';
        $structure->contentType = 'user_note';
        $structure->columns = [
            'note_id' => ['type' => self::UINT, 'autoIncrement' => true, 'changeLog' => false],
            'note_user_id' => ['type' => self::UINT, 'changeLog' => false],
            'user_id' => ['type' => self::UINT, 'changeLog' => false],
            'username' => ['type' => self::STR, 'changeLog' => false],
            'create_date' => ['type' => self::UINT, 'default' => \XF::$time, 'changeLog' => false],
            'message' => ['type' => self::STR, 'changeLog' => false]
        ];
        $structure->getters = [

        ];
        $structure->behaviors = [

        ];
        $structure->options = [
            'log_moderator' => true
        ];
        $structure->relations = [
            'User' => [
                'entity' => 'XF:User',
                'type' => self::TO_ONE,
                'conditions' => 'user_id',
                'primary' => true
            ],
            'NoteUser' => [
                'entity' => 'XF:User',
                'type' => self::TO_ONE,
                'conditions' => [['user_id', '=', '$note_user_id']],
                'primary' => true
            ]
        ];

        return $structure;
    }

}
