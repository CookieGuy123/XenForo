<?php

namespace Andrew\ModeratorPanel\Repository;

use XF\Mvc\Entity\Finder;
use XF\Mvc\Entity\Repository;

class UserNote extends Repository
{

    public function findUserNote()
    {
        $finder = $this->finder('Andrew\ModeratorPanel:UserNote');
        $finder->setDefaultOrder('note_id', 'DESC');

        return $finder;
    }

}