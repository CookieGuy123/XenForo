<?php

namespace Andrew\ModeratorPanel\XF\Entity;
use XF\Mvc\Entity\Structure;
use XF\Mvc\Entity\Entity;


class UserIgnored extends XFCP_UserIgnored
{
    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        $structure->relations['User'] = [
            'entity' => 'XF:User',
            'type' => self::TO_ONE,
            'conditions' => 'user_id'
        ];

        return $structure;
    }

}