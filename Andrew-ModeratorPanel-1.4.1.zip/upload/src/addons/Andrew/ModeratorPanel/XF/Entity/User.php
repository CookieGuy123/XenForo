<?php

namespace Andrew\ModeratorPanel\XF\Entity;
use XF\Mvc\Entity\Structure;

class User extends XFCP_User
{
    public function canViewModeratorPanel(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->hasPermission('andrew_moderatorpanel', 'canViewModeratorPanel'));
    }

    public function canBanProtectedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'canBanProtectedUsers'));
    }
    public function canSearchUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'searchUsers'));
    }
    public function canViewBannedUsersListMP(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewBannedUsersList'));
    }
    public function canViewDiscouragedUsersListMP(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewDiscouragedUsersList'));
    }
    public function canDiscourageUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'addDiscouragedUsers'));
    }
    public function canDiscourageProtectedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'discourageProtectedUsers'));
    }
    public function canViewThreadBan(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewThreadBan'));
    }
    public function canViewRecentlyRegistered(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewRecentlyRegistered'));
    }
    public function canViewWarnedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewWarnedUsers'));
    }
    public function canViewReportedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewReportedUsers'));
    }
    public function canViewIgnoredUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewIgnoredUsers'));
    }
    public function canViewModeratorLog(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewModeratorLog'));
    }
    public function canViewChangeLog(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewChangeLog'));
    }
    public function canViewUsernameChangeLog(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewUserNameChangeLog'));
    }
    public function canViewIPAddresses(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewIPAddresses'));
    }
    public function canViewUserNotes(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewUserNotes'));
    }
    public function canViewRejectedUserLog(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewRejectedUserLog'));
    }
    public function canViewSpamCleanerLog(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewSpamCleanerLog'));
    }
    public function canDeleteUserNote(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'deleteUserNote'));
    }
    public function canAddUserNote(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'addUserNote'));
    }
    public function canViewModeratedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'viewModeratedUsers'));
    }
    public function canModerateUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'addModeratedUsers'));
    }
    public function canModerateProtectedUsers(&$error = null)
    {
        $visitor = \XF::visitor();
        return ($visitor->user_id && $visitor->hasPermission('andrew_moderatorpanel', 'moderateProtectedUsers'));
    }

    public function canBan(&$error = null)
    {

        $visitor = \XF::visitor();
        $options = $this->app()->options();

        $protectedUser = $options->andrewModeratorPanelProtected;
        $protectedEnabled = $options->andrewModeralPanelEnabledProtectedUsers;

        if($protectedEnabled == true)
        {
            foreach ($this->secondary_group_ids as $groupId)
            {
                if ($groupId == $protectedUser && !$visitor->canBanProtectedUsers())
                {
                    return false;
                }
            }
        }

        return parent::canBan($error);

    }

    public function canDiscourage(&$error = null)
    {

        $visitor = \XF::visitor();
        $options = $this->app()->options();

        $protectedUser = $options->andrewModeratorPanelProtected;
        $protectedEnabled = $options->andrewModeralPanelEnabledProtectedUsers;

        if($protectedEnabled == true)
        {
            foreach ($this->secondary_group_ids as $groupId)
            {
                if ($groupId == $protectedUser && !$visitor->canDiscourageProtectedUsers() || $this->user_id == $visitor->user_id)
                {
                    return false;
                }
            }

        }
        return $this->canDiscourageUsers();
    }

    public function canModerate(&$error = null)
    {

        $visitor = \XF::visitor();
        $options = $this->app()->options();

        $protectedUser = $options->andrewModeratorPanelProtected;
        $protectedEnabled = $options->andrewModeralPanelEnabledProtectedUsers;

        if($protectedEnabled == true)
        {
            foreach ($this->secondary_group_ids as $groupId)
            {
                if ($groupId == $protectedUser && !$visitor->canModerateProtectedUsers() || $this->user_id == $visitor->user_id)
                {
                    return false;
                }
            }
        }
        return $this->canModerateUsers();
    }

    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        $structure->relations['SpamCleanerLog'] = [
            'entity' => 'XF:SpamCleanerLog',
            'type' => self::TO_ONE,
            'conditions' => 'user_id',
            'primary' => true
        ];

        return $structure;
    }
}