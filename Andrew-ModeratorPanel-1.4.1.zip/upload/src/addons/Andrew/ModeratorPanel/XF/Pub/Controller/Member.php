<?php

namespace Andrew\ModeratorPanel\XF\Pub\Controller;
use XF\Mvc\ParameterBag;

class Member extends XFCP_Member
{

    public function actionEdit(ParameterBag $params)
    {
        $user = $this->assertViewableUser($params->user_id, [], true);
        if (!$user->canEdit())
        {
            return $this->noPermission();
        }

        $response = parent::actionEdit($params);
        $notAdmin = $this->filter('not_admin', 'bool');

        if ($this->isPost())
        {
            $this->memberSaveProcess($user)->run();
            return $this->redirect($this->buildLink('members/edit', $user, $notAdmin ? ['not_admin' => 1] : []));
        }
        else
        {
            if (\XF::visitor()->hasAdminPermission('user') && !$notAdmin)
            {
                /** @var \XF\Mvc\Router $router */
                $router = $this->app->container('router.admin');
                return $this->redirect($router->buildLink('users/edit', $user));
            }
        }

        $options = $this->app()->options();
        $moderatedUsers = $options->andrewModeratorPanelModeratedUsergroup;

        $groupIds = $user->secondary_group_ids;

        foreach ($groupIds as $groupId)
        {
            if ($groupId == $moderatedUsers)
            {
                $response->setParam('is_moderated', true);
                break;
            }
        }

        if ($user->canModerate())
        {
            $response->setParam('moderatedProtected', false);
        }
        else
        {
            $response->setParam('moderatedProtected', true);
        }

        if ($user->canDiscourage())
        {
            $response->setParam('discourageProtected', false);
        }
        else
        {
            $response->setParam('discourageProtected', true);
        }

       return $response;

    }

    protected function memberSaveProcess(\XF\Entity\User $user)
    {

        $response = parent::memberSaveProcess($user);

        $is_moderated = $this->filter('is_moderated','bool' );

        if ($user->canModerate())
        {
            $this->moderateUser($user,$is_moderated);
        }

        if ($user->canDiscourage())
        {
            $this->discourageUser($user,$response);
        }

        return $response;
    }
    public function actionDiscourage(ParameterBag $params)
    {
        $userId = $params->user_id;

        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canDiscourage())
        {
            return $this->noPermission();
        }

        $viewParams = [
            'user' => $user
        ];

        return $this->view('XF:Member\Discourage', 'andrew_moderatorpanel_discourage_user_overlay',$viewParams);
    }

    public function actionRemoveDiscourage(ParameterBag $params)
    {
        $userId = $params->user_id;

        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canDiscourage())
        {
            return $this->noPermission();
        }

        $viewParams = [
            'user' => $user
        ];

        return $this->view('XF:Member\RemoveDiscourage', 'andrew_moderatorpanel_remove_discourage_user_overlay',$viewParams);
    }

    public function actionDiscourageSave(ParameterBag $params)
    {
        $userId = $params->user_id;
        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canDiscourage())
        {
            return $this->noPermission();
        }

        $input = $this->filter([
            'option' => [
                'is_discouraged' => 'bool'
            ]
        ]);

        $userOptions = $user->getRelationOrDefault('Option');
        $userOptions->is_discouraged = $input['option']['is_discouraged'];
        $userOptions->save();

        return $this->redirect($this->getDynamicRedirect());
    }

    protected function discourageUser($user, $response)
    {
        $input = $this->filter([
            'option' => [
                'is_discouraged' => 'bool'
            ]
        ]);

        $userOptions = $user->getRelationOrDefault('Option');
        $response->setupEntityInput($userOptions, $input['option']);
    }
    public function actionModerate(ParameterBag $params)
    {
        $userId = $params->user_id;

        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canModerate())
        {
            return $this->noPermission();
        }

        $viewParams = [
            'user' => $user
        ];

        return $this->view('XF:Member\Moderate', 'andrew_moderatorpanel_moderate_user_overlay',$viewParams);
    }
    public function actionRemoveModerate(ParameterBag $params)
    {
        $userId = $params->user_id;

        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canModerate())
        {
            return $this->noPermission();
        }

        $viewParams = [
            'user' => $user
        ];

        return $this->view('XF:Member\RemoveModerate', 'andrew_moderatorpanel_remove_moderate_user_overlay',$viewParams);
    }
    public function actionModerateSave(ParameterBag $params)
    {
        $userId = $params->user_id;
        $finder = \XF::finder('XF:User');
        $user = $finder->where('user_id',$userId)->fetchOne();

        if (!$user->canModerate())
        {
            return $this->noPermission();
        }

        $is_moderated = $this->filter('is_moderated', 'bool');

        $this->moderateUser($user, $is_moderated);

        return $this->redirect($this->getDynamicRedirect());
    }
    protected function moderateUser($user, $is_moderated)
    {
        $options = $this->app()->options();
        $moderatedUsers = $options->andrewModeratorPanelModeratedUsergroup;
        $userGroupChange = \XF::service('XF:User\UserGroupChange');

        if($is_moderated == true)
        {
            $userGroupChange->addUserGroupChange($user->user_id, 'ModEdit', [$moderatedUsers]);
        }
        else
        {
            $userGroupChange->removeUserGroupChange($user->user_id, 'ModEdit');
        }
    }
}