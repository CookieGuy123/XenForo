<?php

namespace Andrew\ModeratorPanel\Pub\Controller;
use XF\Mvc\ParameterBag;

class UserNote extends \XF\Pub\Controller\AbstractController
{
    public function actionSave(ParameterBag $params)
    {
        $visitor = \XF::visitor();

        if (!$visitor->canAddUserNote())
        {
            return $this->noPermission();
        }

        $user_id = $this->filter('user_id', 'int');
        $message = $this->plugin('XF:Editor')->fromInput('message');

        $user_note = \XF::em()->create('Andrew\ModeratorPanel:UserNote');
        $user_note->note_user_id = $user_id;
        $user_note->username = $visitor->username;
        $user_note->user_id = $visitor->user_id;
        $user_note->message = $message;
        $user_note->save();

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        return $this->redirect($this->buildLink('moderatorpanel/user/#user_notes',$user));

    }
    public function actionDelete(ParameterBag $params)
    {
        $visitor = \XF::visitor();

        if (!$visitor->canDeleteUserNote())
        {
            return $this->noPermission();
        }

        $note_id = $params->note_id;

        $repo = $this->repository('Andrew\ModeratorPanel:UserNote');
        $finder = $repo->findUserNote();
        $user_note = $finder->where('note_id', $note_id)->fetchOne();
        $user_id = $user_note->note_user_id;
        $user_note->delete();

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        return $this->redirect($this->buildLink('moderatorpanel/user/#user_notes',$user));

    }
}