<?php

namespace Andrew\ModeratorPanel\Pub\Controller;
use XF\Mvc\Entity\Finder;
use XF\Mvc\ParameterBag;

class ModeratorPanel extends \XF\Pub\Controller\AbstractController
{
    public function actionIndex()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $stats = [];

        /** @var \XF\Stats\Grouper\AbstractGrouper $grouper */
        $grouper = $this->app->create('stats.grouper', 'daily');

        foreach ($this->getDashboardStatGraphs() AS $statDisplayTypes)
        {
            $now = \XF::$time;
            $start = $now - 30*86400;
            $end = $now - ($now % 86400) - 1; // yesterday

            /** @var \XF\Service\Stats\Grapher $grapher */
            $grapher = $this->service('XF:Stats\Grapher', $start, $end, $statDisplayTypes);
            $stats[] = [
                'data' => $grapher->getGroupedData($grouper),
                'phrases' => $this->repository('XF:Stats')->getStatsTypePhrases($statDisplayTypes)
            ];
        }

        $showSpamUsers = $this->options()->andrewModeratorPanelShowSpamBan;
        $spamCleanerPhrase = \XF::phrase('spam_cleaner_ban_reason');
        $spamPhrase = \XF::phrase('spam');

        If($showSpamUsers == 1) {

            $finder = \XF::finder('XF:User');
            $bannedusers = $finder
                ->with('Ban')
                ->where('is_banned', 1)
                ->order('Ban.ban_date', 'DESC')
                ->limit(10)
                ->fetch();
        }
        else
        {
            $finder = \XF::finder('XF:User');
            $bannedusers = $finder
                ->with('Ban')
                ->with('SpamCleanerLog',false)
                ->where('is_banned',1)
                ->where('SpamCleanerLog.user_id', null)
                ->where('Ban.user_reason','!=',$spamCleanerPhrase)
                ->where('Ban.user_reason','!=',$spamPhrase)
                ->order('Ban.ban_date', 'DESC')
                ->limit(10)
                ->fetch();
        }

        $finder = \XF::finder('XF:Warning');
        $warnings = $finder
            ->with('User')
            ->order('warning_date','DESC')
            ->limit(10);

        $activityRepo = $this->repository('XF:SessionActivity');

        $reportRepo = $this->repository('XF:Report');
        $closedReportsFinder = $reportRepo->findReports(['resolved', 'rejected'], time() - 86400);
        $closedReports = $closedReportsFinder->fetch();
        $closedReports = $closedReports->filterViewable();

        $repo = $this->repository('Andrew\ModeratorPanel:UserNote');
        $finder = $repo->findUserNote();
        $user_notes = $finder->with('User')->fetch(5);

        $positionOne = $this->options()->andrewModeratorPanelDashboardFirstPosition;
        $positionTwo = $this->options()->andrewModeratorPanelDashboardSecondPosition;
        $positionThree = $this->options()->andrewModeratorPanelDashboardThirdPosition;
        $positionFour = $this->options()->andrewModeratorPanelDashboardFourthPosition;
        $positionFive = $this->options()->andrewModeratorPanelDashboardFifthPosition;

        $viewParams = [
            'stats' => $stats,
            'bannedusers' => $bannedusers,
            'warnings' => $warnings,
            'counts' => $activityRepo->getOnlineCounts(),
            'user_notes' => $user_notes,
            'reportCount' => $closedReports->count(),
            'positionOne' => $positionOne,
            'positionTwo' => $positionTwo,
            'positionThree' => $positionThree,
            'positionFour' => $positionFour,
            'positionFive' => $positionFive
        ];

        return $this->view('Andrew\ModeratorPanel:View', 'andrew_moderatorpanel_view',$viewParams);
    }

    protected function getDashboardStatGraphs()
    {
        return [
            ['post', 'thread'],
            ['user_registration', 'user_activity']
        ];
    }

    public function actionBannedUsers()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewBannedUsersListMP())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $showSpamUsers = $this->options()->andrewModeratorPanelShowSpamBan;
        $spamCleanerPhrase = \XF::phrase('spam_cleaner_ban_reason');
        $spamPhrase = \XF::phrase('spam');

        If($showSpamUsers == 1) {

            $finder = \XF::finder('XF:User')->limitByPage($page, $perPage);
            $users = $finder
                ->with('Ban')
                ->where('is_banned', 1)
                ->order('Ban.ban_date', 'DESC')
                ->fetch();
        }
        else
        {
            $finder = \XF::finder('XF:User')->limitByPage($page, $perPage);
            $users = $finder
                ->with('Ban')
                ->with('SpamCleanerLog',false)
                ->where('is_banned',1)
                ->where('SpamCleanerLog.user_id', null)
                ->where('Ban.user_reason','!=',$spamCleanerPhrase)
                ->where('Ban.user_reason','!=',$spamPhrase)
                ->order('Ban.ban_date', 'DESC')
                ->fetch();
        }

        $viewParams = [
            'total' => $finder->total(),
            'page' => $page,
            'perPage' => $perPage,
            'users' => $users
        ];

        return $this->view('Andrew\ModeratorPanel\BannedUsers:View', 'andrew_moderatorpanel_bannedusers_view',$viewParams);
    }

    public function actionDiscouragedUsers()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewDiscouragedUsersListMP())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:User')->limitByPage($page, $perPage);
        $users = $finder
            ->with('Option')
            ->where('Option.is_discouraged',1)
            ->order('username','ASC')
            ->fetch();

        $viewParams = [
            'total' => $finder->total(),
            'page' => $page,
            'perPage' => $perPage,
            'users' => $users
        ];

        return $this->view('Andrew\ModeratorPanel\DiscouragedUsers:View', 'andrew_moderatorpanel_discouragedusers_view',$viewParams);
    }

    public function actionRecentRegistered()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewRecentlyRegistered())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:User')->limitByPage($page, $perPage);
        $users = $finder
            ->order('register_date','DESC')
            ->fetch();

        $viewParams = [
            'total' => $finder->total(),
            'page' => $page,
            'perPage' => $perPage,
            'users' => $users
        ];

        return $this->view('Andrew\ModeratorPanel\RecentRegistered:View', 'andrew_moderatorpanel_recentregistered_view',$viewParams);
    }
    public function actionUserNotes()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() && !$visitor->canViewUserNotes())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 20;

        $repo = $this->repository('Andrew\ModeratorPanel:UserNote');
        $finder = $repo->findUserNote()->limitByPage($page, $perPage);;
        $user_notes = $finder->with('User')->fetch();

        $viewParams = [
            'user_notes' => $user_notes
        ];

        return $this->view('Andrew\ModeratorPanel\UserNotes:View', 'andrew_moderatorpanel_user_notes_view', $viewParams);
    }

    public function actionThreadBanList()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewThreadBan())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:ThreadReplyBan')->limitByPage($page, $perPage);
        $users = $finder
            ->with('User')
            ->with('Thread')
            ->order('ban_date','DESC')
            ->fetch();

        $viewParams = [
            'total' => $finder->total(),
            'page' => $page,
            'perPage' => $perPage,
            'users' => $users
        ];

        return $this->view('Andrew\ModeratorPanel\ThreadBanList:View', 'andrew_moderatorpanel_threadbanlist_view',$viewParams);
    }

    public function actionModeratedUsers()
    {
        $options = $this->app()->options();
        $moderatedUsers = $options->andrewModeratorPanelModeratedUsergroup;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratedUsers() || $moderatedUsers == 0)
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:User')->limitByPage($page, $perPage);
        $inSet = $finder->expression("FIND_IN_SET(". $moderatedUsers .", secondary_group_ids)");
        $users = $finder->where($inSet)->fetch();

        $viewParams = [
            'total' => $finder->total(),
            'page' => $page,
            'perPage' => $perPage,
            'users' => $users
        ];

        return $this->view('Andrew\ModeratorPanel\ModeratedUsers:View', 'andrew_moderatorpanel_moderatedusers_view',$viewParams);
    }

    public function actionMostReportedUsers()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewReportedUsers())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;
        $offset = ($page - 1) * $perPage;

        $showBannedUsers = $this->options()->andrewModeratorPanelMostReportedBannedUsers;

        $db = \XF::db();

        if($showBannedUsers == 1) {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points, sum(xf_report.report_count) as report_count
                                    from xf_user
                                    inner join xf_report on xf_user.user_id = xf_report.content_user_id
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_report.report_id) > 0
                                    order by report_count DESC
                                    limit ?,?", 'user_id', [$offset, $perPage]);

            $total  = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points, sum(xf_report.report_count) as report_count
                                    from xf_user
                                    inner join xf_report on xf_user.user_id = xf_report.content_user_id
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_report.report_id) > 0
                                    order by report_count DESC");
        }
        else
        {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points, sum(xf_report.report_count) as report_count
                                    from xf_user
                                    inner join xf_report on xf_user.user_id = xf_report.content_user_id
                                    where xf_user.is_banned != 1
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_report.report_id) > 0
                                    order by report_count DESC
                                    limit ?,?", 'user_id', [$offset, $perPage]);

            $total = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points, sum(xf_report.report_count) as report_count
                                    from xf_user
                                    inner join xf_report on xf_user.user_id = xf_report.content_user_id
                                    where xf_user.is_banned != 1
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_report.report_id) > 0
                                    order by report_count DESC");
        }

        $users = \XF::em()->findByIds('XF:User', array_keys($values));
        $users = $users->sortByList(array_keys($values));
        $total = count($total);

        $viewParams = [
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'users' => $users,
            'values' => $values
        ];

        return $this->view('Andrew\ModeratorPanel\MostReportedUsers:View', 'andrew_moderatorpanel_mostreportedusers_view',$viewParams);
    }

    public function actionMostWarnedUsers()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewWarnedUsers())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;
        $offset = ($page - 1) * $perPage;
        $showBannedUsers = $this->options()->andrewModeratorPanelMostWarnedBannedUsers;

        $db = \XF::db();

        if($showBannedUsers == 1) {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_warning.warning_id) as warning_count, xf_user.warning_points as active_points, sum(xf_warning.points) total_points
                                        from xf_user
                                        inner join xf_warning on xf_user.user_id = xf_warning.user_id
                                        group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                        having count(xf_warning.warning_id) > 0
                                        order by warning_count desc
                                        limit ?,?", 'user_id', [$offset, $perPage]);

            $total = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_warning.warning_id) as warning_count, xf_user.warning_points as active_points, sum(xf_warning.points) total_points
                                        from xf_user
                                        inner join xf_warning on xf_user.user_id = xf_warning.user_id
                                        group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                        having count(xf_warning.warning_id) > 0
                                        order by warning_count desc");
        }
        else
        {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_warning.warning_id) as warning_count, xf_user.warning_points as active_points, sum(xf_warning.points) total_points
                                        from xf_user
                                        inner join xf_warning on xf_user.user_id = xf_warning.user_id
                                        where xf_user.is_banned != 1
                                        group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                        having count(xf_warning.warning_id) > 0
                                        order by warning_count desc
                                        limit ?,?", 'user_id', [$offset, $perPage]);

            $total = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_warning.warning_id) as warning_count, xf_user.warning_points as active_points, sum(xf_warning.points) total_points
                                        from xf_user
                                        inner join xf_warning on xf_user.user_id = xf_warning.user_id
                                        where xf_user.is_banned != 1
                                        group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                        having count(xf_warning.warning_id) > 0
                                        order by warning_count desc");
        }

        $users = \XF::em()->findByIds('XF:User', array_keys($values));
        $users = $users->sortByList(array_keys($values));
        $total = count($total);

        $viewParams = [
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'users' => $users,
            'values' => $values
        ];

        return $this->view('Andrew\ModeratorPanel\MostWarnedUsers:View', 'andrew_moderatorpanel_mostwarnedusers_view',$viewParams);
    }

    public function actionMostIgnoredUsers()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewIgnoredUsers())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;
        $offset = ($page - 1) * $perPage;

        $showBannedUsers = $this->options()->andrewModeratorPanelMostIgnoredBannedUsers;

        $db = \XF::db();

        if($showBannedUsers == 1) {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_user_ignored.ignored_user_id) as ignored_count
                                            from xf_user
                                            inner join xf_user_ignored on xf_user.user_id = xf_user_ignored.ignored_user_id
                                            group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                            having count(xf_user_ignored.ignored_user_id) > 0
                                            order by ignored_count desc
                                            limit ?,?", 'user_id', [$offset, $perPage]);

            $total = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_user_ignored.ignored_user_id) as ignored_count
                                            from xf_user
                                            inner join xf_user_ignored on xf_user.user_id = xf_user_ignored.ignored_user_id
                                            group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                            having count(xf_user_ignored.ignored_user_id) > 0
                                            order by ignored_count desc");
        }
        else
        {
            $values = $db->fetchAllKeyed("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_user_ignored.ignored_user_id) as ignored_count
                                            from xf_user
                                            inner join xf_user_ignored on xf_user.user_id = xf_user_ignored.ignored_user_id
                                            where xf_user.is_banned != 1
                                            group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                            having count(xf_user_ignored.ignored_user_id) > 0
                                            order by ignored_count desc
                                            limit ?,?", 'user_id', [$offset, $perPage]);

            $total = $db->fetchAll("select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_user_ignored.ignored_user_id) as ignored_count
                                            from xf_user
                                            inner join xf_user_ignored on xf_user.user_id = xf_user_ignored.ignored_user_id
                                            where xf_user.is_banned != 1
                                            group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                            having count(xf_user_ignored.ignored_user_id) > 0
                                            order by ignored_count desc");
        }

        $users = \XF::em()->findByIds('XF:User', array_keys($values));
        $users = $users->sortByList(array_keys($values));
        $total = count($total);

        $viewParams = [
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'users' => $users,
            'values' => $values
        ];

        return $this->view('Andrew\ModeratorPanel\MostIgnoredUsers:View', 'andrew_moderatorpanel_mostignoredusers_view',$viewParams);
    }
    public function actionModeratorLog(ParameterBag $params)
    {

        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewModeratorLog())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 20;

        $repo = $this->repository('XF:ModeratorLog');

        $finder = $repo->findLogsForList()
            ->limitByPage($page, $perPage);

        $linkFilters = [];
        if ($userId = $this->filter('user_id', 'uint'))
        {
            $linkFilters['user_id'] = $userId;
            $finder->where('user_id', $userId);
        }

        if ($this->isPost())
        {
            // redirect to give a linkable page
            return $this->redirect($this->buildLink('moderatorpanel/moderator-log', null, $linkFilters));
        }

        $viewParams = [
            'entries' => $finder->fetch(),
            'logUsers' => $repo->getUsersInLog(),
            'userId' => $userId,
            'page' => $page,
            'perPage' => $perPage,
            'total' => $finder->total(),
            'linkFilters' => $linkFilters
        ];
        return $this->view('Andrew\ModeratorPanel\ModeratorLog:View', 'andrew_moderatorpanel_log_moderator_list', $viewParams);
    }

    public function actionUserChangeLog(ParameterBag $params)
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewChangeLog())
        {
            return $this->noPermission();
        }

        $this->setSectionContext('userChangeLog');

        $page = $this->filterPage();
        $perPage = 20;

        $changeRepo = $this->repository('XF:ChangeLog');
        $changeFinder = $changeRepo->findChangeLogsByContentType('user')->limitByPage($page, $perPage);

        $changes = $changeFinder->fetch();
        $changeRepo->addDataToLogs($changes);

        $viewParams = [
            'changesGrouped' => $changeRepo->groupChangeLogs($changes),
            'totalChanges' => count($changes),
            'page' => $page,
            'perPage' => $perPage,
            'total' => $changeFinder->total(),
        ];
        return $this->view('Andrew\ModeratorPanel\UserChangeLog:View', 'andrew_moderatorpanel_user_change_log', $viewParams);
    }

    public function actionUsernameChangeLog(ParameterBag $params)
    {

        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewUsernameChangeLog()) {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 20;

        $usernameChangeRepo = $this->repository('XF:UsernameChange');
        $entryFinder = $usernameChangeRepo->findUsernameChangesForList()
            ->limitByPage($page, $perPage);

        $entries = $entryFinder->fetch();

        $viewParams = [
            'entries' => $entries,

            'page' => $page,
            'perPage' => $perPage,
            'total' => $entryFinder->total()
        ];
        return $this->view('Andrew\ModeratorPanel\UsernameChangeLog\Listing', 'andrew_moderatorpanel_user_name_change_list', $viewParams);

    }

    public function actionRejectedUserLog(ParameterBag $params)
    {

        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewRejectedUserLog()) {
            return $this->noPermission();
        }

        $this->setSectionContext('rejectedUserLog');

        if ($params->user_id)
        {
            $entry = $this->assertRejectedUserLogExists($params->user_id);

            $viewParams = [
                'entry' => $entry
            ];
            return $this->view('Andrew\ModeratorPanel\RejectedUserLog\View', 'andrew_moderatorpanel_rejected_user_view', $viewParams);
        }
        else
        {
            /** @var \XF\Repository\UserReject $rejectRepo */
            $rejectRepo = $this->repository('XF:UserReject');

            $page = $this->filterPage();
            $perPage = 20;

            $finder = $rejectRepo->findUserRejectionsForList()->limitByPage($page, $perPage);

            $viewParams = [
                'rejections' => $finder->fetch(),
                'total' => $finder->total(),

                'page' => $page,
                'perPage' => $perPage
            ];
            return $this->view('Andrew\ModeratorPanel\RejectedUserLog\Listing', 'andrew_moderatorpanel_rejected_user_list', $viewParams);
        }
    }
    protected function assertRejectedUserLogExists($id, $with = null, $phraseKey = null)
    {
        return $this->assertRecordExists('XF:UserReject', $id, $with, $phraseKey);
    }

    public function actionSpamCleanerLog()
    {
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() || !$visitor->canViewSpamCleanerLog()) {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 20;

        $repo = $this->repository('XF:Spam');
        $finder = $repo->findSpamCleanerLogsForList()
            ->limitByPage($page, $perPage);

        $viewParams = [
            'entries' => $finder->fetch(),
            'page' => $page,
            'perPage' => $perPage,
            'total' => $finder->total()
        ];
        return $this->view('Andrew\ModeratorPanel\SpamCleanerLog\Listing', 'andrew_moderatorpanel_spam_cleaner_list', $viewParams);
    }
}