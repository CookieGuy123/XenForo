<?php

namespace Andrew\ModeratorPanel\Pub\Controller;
use XF\Mvc\ParameterBag;

class User extends \XF\Pub\Controller\AbstractController
{
    public function actionIndex(ParameterBag $params)
    {
        if (isset($params['user_id']))
        {
            return $this->rerouteController(__CLASS__, 'view', $params);
        }
    }

    public function actionView(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $db = \XF::db();

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->with('Ban')
            ->where('user_id',$user_id)
            ->fetchOne();

        if(!$user)
        {
            throw $this->exception($this->notFound(\XF::phrase('andrew_moderatorpanel_user_not_found')));
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:Warning')->limitByPage($page, $perPage);
        $warnings = $finder
            ->with('User')
            ->where('user_id',$user_id)
            ->order('warning_date','DESC')
            ->fetch();

        $warning_points = $db->fetchRow('select xf_user.user_id, xf_user.username, xf_user.message_count, count(xf_warning.warning_id) as warning_count, xf_user.warning_points as active_points, sum(xf_warning.points) total_points
                                    from xf_user
                                    inner join xf_warning on xf_user.user_id = xf_warning.user_id
                                    where xf_user.user_id = ?
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_warning.warning_id) > 0
                                    order by warning_count desc',$user_id);


        $report_count = $db->fetchRow("select xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points, sum(xf_report.report_count) as report_count
                                    from xf_user
                                    inner join xf_report on xf_user.user_id = xf_report.content_user_id
                                    where xf_user.user_id = ?
                                    group by xf_user.user_id, xf_user.username, xf_user.message_count, xf_user.warning_points
                                    having sum(xf_report.report_id) > 0
                                    order by report_count DESC",$user_id);

        $finder = \XF::finder('XF:UserIgnored');
        $ignored = $finder
            ->where('ignored_user_id',$user_id)
            ->fetch();

        $finder = \XF::finder('XF:ThreadReplyBan')->limitByPage($page, $perPage);
        $thread_bans = $finder
            ->with('User')
            ->with('Thread')
            ->where('user_id',$user_id)
            ->order('ban_date','DESC')
            ->fetch();

        $viewParams = [
            'user' => $user,
            'warnings' => $warnings,
            'warning_points' => $warning_points,
            'report_count' => $report_count,
            'ignored' => $ignored,
            'thread_bans' => $thread_bans
        ];

        return $this->view('Andrew\ModeratorPanel:User\View', 'andrew_moderatorpanel_user_view',$viewParams);
    }

    public function actionCurrentBan(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->with('Ban')
            ->where('user_id',$user_id)
            ->fetchOne();

        $viewParams = [
            'user' => $user
        ];

        return $this->view('Andrew\ModeratorPanel:User\CurrentBan', 'andrew_moderatorpanel_user_ban_list', $viewParams);
    }

    public function actionWarnings(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:Warning')->limitByPage($page, $perPage);
        $warnings = $finder
            ->with('User')
            ->where('user_id',$user_id)
            ->order('warning_date','DESC')
            ->fetch();

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        $viewParams = [
            'warnings' => $warnings,
            'user' => $user
        ];

        return $this->view('Andrew\ModeratorPanel:User\Warnings', 'andrew_moderatorpanel_user_warning_list', $viewParams);
    }

    public function actionReports(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:Report')->limitByPage($page, $perPage);
        $reports = $finder
            ->with('User')
            ->where('content_user_id',$user_id)
            ->order('first_report_date','ASC')
            ->fetch();

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        $viewParams = [
            'reports' => $reports,
            'user' => $user
        ];

        return $this->view('Andrew\ModeratorPanel:User\Reports', 'andrew_moderatorpanel_user_report_list', $viewParams);
    }

    public function actionThreadBans(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:ThreadReplyBan')->limitByPage($page, $perPage);
        $threadbans = $finder
            ->with('User')
            ->with('Thread')
            ->where('user_id',$user_id)
            ->order('ban_date','DESC')
            ->fetch();

        $viewParams = [
            'threadbans' => $threadbans
        ];

        return $this->view('Andrew\ModeratorPanel:User\ThreadBans', 'andrew_moderatorpanel_user_threadbans_list', $viewParams);
    }

    public function actionIgnoredBy(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $page = $this->filterPage();
        $perPage = 40;

        $finder = \XF::finder('XF:UserIgnored')->limitByPage($page, $perPage);
        $ignores = $finder
            ->with('User',$user_id)
            ->where('ignored_user_id',$user_id)
            ->fetch();

        $ignore_count = count($ignores);

        $viewParams = [
            'ignores' => $ignores,
            'ignore_count' => $ignore_count,
            'perPage'
        ];

        return $this->view('Andrew\ModeratorPanel:User\IgnoredBy', 'andrew_moderatorpanel_user_ignores_list', $viewParams);
    }

    public function actionIpAddresses(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        /** @var \XF\Repository\Ip $ipRepo */
        $ipRepo = $this->repository('XF:Ip');

        $ips = $ipRepo->getIpsByUser($user);

        $viewParams = [
            'user' => $user,
            'ips' => $ips
        ];
        return $this->view('Andrew\ModeratorPanel:User\IpAddresses', 'andrew_moderatorpanel_user_ip_list', $viewParams);
    }

    public function actionUserNotes(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel() && !$visitor->canViewUserNotes())
        {
            return $this->noPermission();
        }

        $repo = $this->repository('Andrew\ModeratorPanel:UserNote');
        $finder = $repo->findUserNote();
        $user_notes = $finder->with('User')
            ->where('note_user_id', $user_id)
            ->fetch();

        $viewParams = [
            'user_notes' => $user_notes,
            'user_id' => $user_id
        ];

        return $this->view('Andrew\ModeratorPanel:User\UserNotes', 'andrew_moderatorpanel_user_notes_list', $viewParams);
    }

    public function actionChangeLog(ParameterBag $params)
    {
        $user_id = $params->user_id;
        $visitor = \XF::visitor();

        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $finder = \XF::finder('XF:User');
        $user = $finder
            ->where('user_id',$user_id)
            ->fetchOne();

        $page = $this->filterPage();
        $perPage = 20;

        $repo = $this->repository('XF:ChangeLog');
        $finder = $repo->findChangeLogsByContent('user', $user->user_id)->limitByPage($page, $perPage);

        $changes = $finder->fetch();
        $repo->addDataToLogs($changes);

        $viewParams = [
            'user' => $user,
            'changesGrouped' => $repo->groupChangeLogs($changes),
        ];

        return $this->view('Andrew\ModeratorPanel:User\ChangeLog', 'andrew_moderatorpanel_user_change_log_profile', $viewParams);
    }

    public function actionSearch()
    {
        $visitor = \XF::visitor();
        if (!$visitor->canViewModeratorPanel() || !$visitor->canSearchUsers())
        {
            return $this->noPermission();
        }

        $this->setSectionContext('searchForUsers');

        $lastUserId = $this->filter('last_user_id', 'uint');
        $lastUser = $lastUserId ? $this->em()->find('XF:User', $lastUserId) : null;

        $viewParams = $this->getSearcherParams($lastUser ? ['lastUser' => $lastUser] : []);

        return $this->view('Andrew\ModeratorPanel:User\Search', 'andrew_moderatorpanel_user_search', $viewParams);
    }

    protected function getSearcherParams(array $extraParams = [])
    {
        $visitor = \XF::visitor();
        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $searcher = $this->searcher('XF:User');

        $viewParams = [
            'criteria' => $searcher->getFormCriteria(),
            'sortOrders' => $searcher->getOrderOptions()
        ];
        return $viewParams + $searcher->getFormData() + $extraParams;
    }

    public function actionIpUsers()
    {
        $visitor = \XF::visitor();
        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        /** @var \XF\Repository\Ip $ipRepo */
        $ipRepo = $this->repository('XF:Ip');

        $ip = $this->filter('ip', 'str');
        $parsed = \XF\Util\Ip::parseIpRangeString($ip);

        if (!$parsed)
        {
            return $this->message(\XF::phrase('please_enter_valid_ip_or_ip_range'));
        }
        else if ($parsed['isRange'])
        {
            $ips = $ipRepo->getUsersByIpRange($parsed['startRange'], $parsed['endRange']);
        }
        else
        {
            $ips = $ipRepo->getUsersByIp($parsed['startRange']);
        }

        if ($ips)
        {
            $viewParams = [
                'ip' => $ip,
                'ipParsed' => $parsed,
                'ipPrintable' => $parsed['printable'],
                'ips' => $ips
            ];
            return $this->view('Andrew\ModeratorPanel:User\IpUsers', 'andrew_moderatorpanel_ip_users_list', $viewParams);
        }
        else
        {
            return $this->message(\XF::phrase('no_users_logged_at_ip'));
        }
    }

    public function actionList()
    {
        $visitor = \XF::visitor();
        if (!$visitor->canViewModeratorPanel())
        {
            return $this->noPermission();
        }

        $criteria = $this->filter('criteria', 'array');

        $page = $this->filterPage();
        $perPage = 40;

        $searcher = $this->searcher('XF:User', $criteria);

        $finder = $searcher->getFinder();
        $finder->limitByPage($page, $perPage);

        $filter = $this->filter('_xfFilter', [
            'text' => 'str',
            'prefix' => 'bool'
        ]);
        if (strlen($filter['text']))
        {
            $finder->where('username', 'LIKE', $finder->escapeLike($filter['text'], $filter['prefix'] ? '?%' : '%?%'));
        }

        $total = $finder->total();
        $users = $finder->fetch();

        $this->assertValidPage($page, $perPage, $total, 'moderatorpanel/user/list');

        if (!strlen($filter['text']) && $total == 1 && ($user = $users->first()))
        {
            return $this->redirect($this->buildLink('moderatorpanel/user', $user));
        }

        $viewParams = [
            'users' => $users,

            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,

        ];
        return $this->view('Andrew\ModeratorPanel:User\List', 'andrew_moderatorpanel_user_list', $viewParams);
    }
}