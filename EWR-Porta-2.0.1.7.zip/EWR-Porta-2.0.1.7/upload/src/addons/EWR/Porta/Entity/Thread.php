<?php

namespace EWR\Porta\Entity;

use XF\Mvc\Entity\Structure;

class Thread extends XFCP_Thread
{
	protected function _postDelete()
	{
		if ($this->Article)
		{
			$this->db()->delete('ewr_porta_articles', 'thread_id = ?', $this->thread_id);
			$this->db()->delete('ewr_porta_catlinks', 'thread_id = ?', $this->thread_id);
		}
		
		if ($this->Feature)
		{
			$this->db()->delete('ewr_porta_features', 'thread_id = ?', $this->thread_id);
			
			$image = \XF::getRootDirectory() . '/data/features/' . $this->thread_id . '.jpg';
			if (file_exists($image)) { unlink($image); }
		}
		
		return parent::_postDelete();
	}
	
	public static function getStructure(Structure $structure)
	{
		$parent = parent::getStructure($structure);
		
		$structure->relations['Article'] = [
			'entity' => 'EWR\Porta:Article',
			'type' => self::TO_ONE,
			'conditions' => 'thread_id',
			'key' => 'article_id',
		];
		$structure->relations['Feature'] = [
			'entity' => 'EWR\Porta:Feature',
			'type' => self::TO_ONE,
			'conditions' => 'thread_id',
			'key' => 'feature_id',
		];
		
		return $parent;
	}
}