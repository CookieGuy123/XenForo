<?php

namespace EWR\Porta\BbCode;

use XF\BbCode\Renderer\AbstractRenderer;

class Prebreak
{
    public static function bbcode($tagChildren, $tagOption, $tag, array $options, $renderer)
    {
		return '';
	}
}