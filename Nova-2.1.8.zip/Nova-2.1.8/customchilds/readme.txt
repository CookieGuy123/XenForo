Custom Child XML's are styles you import as a child style of the purchased style (the xml found in /xml/ folder).

You can edit these directly and make it your live style if you want.

When upgrading, do not import and overwrite the custom child style, only do the main parent, in this case Nova