<?php

namespace EWR\Carta\Listener;

class UserManagement
{
    public static function userContentChangeInit(\XF\Service\User\ContentChange $changeService, array &$updates)
    {
		$updates['ewr_carta_history'] = ['user_id', 'username'];
		$updates['ewr_carta_watch'] = ['user_id'];
    }
	
    public static function userDeleteCleanInit(\XF\Service\User\DeleteCleanUp $deleteService, array &$deletes)
    {
		$deletes['ewr_carta_watch'] = 'user_id = ?';
    }
}