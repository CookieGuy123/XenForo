<?php

namespace EWR\Carta\Listener;

class Importer
{
    public static function importImporterClass(\XF\SubContainer\Import $container, \XF\Container $parentContainer, array &$importers)
    {
		$importers[] = 'EWR\Carta:Carta140';
    }
}