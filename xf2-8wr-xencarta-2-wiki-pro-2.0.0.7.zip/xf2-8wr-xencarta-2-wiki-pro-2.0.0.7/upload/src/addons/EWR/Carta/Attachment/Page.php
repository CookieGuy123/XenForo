<?php

namespace EWR\Carta\Attachment;

use XF\Entity\Attachment;
use XF\Mvc\Entity\Entity;

class Page extends \XF\Attachment\AbstractHandler
{
	public function canView(Attachment $attachment, Entity $container, &$error = null)
	{
		return $container->canViewAttachments();
	}

	public function canManageAttachments(array $context, &$error = null)
	{
		$em = \XF::em();

		if (!empty($context['page_id']))
		{
			$wiki = $em->find('EWR\Carta:Page', intval($context['page_id']));
			if (!$wiki || !$wiki->canEdit())
			{
				return false;
			}

			return $wiki->canUploadAndManageAttachments();
		}
		else
		{
			$wiki = $em->create('EWR\Carta:Page');
			return $wiki->canUploadAndManageAttachments();
		}
	}

	public function onAttachmentDelete(Attachment $attachment, Entity $container = null)
	{
		return;
	}

	public function getConstraints(array $context)
	{
		return \XF::repository('XF:Attachment')->getDefaultAttachmentConstraints();
	}

	public function getContainerIdFromContext(array $context)
	{
		return isset($context['page_id']) ? intval($context['page_id']) : null;
	}

	public function getContainerLink(Entity $container, array $extraParams = [])
	{
		return \XF::app()->router('public')->buildLink('ewr-carta', $container, $extraParams);
	}

	public function getContext(Entity $entity = null, array $extraContext = [])
	{
		if ($entity instanceof \EWR\Carta\Entity\Page)
		{
			$extraContext['page_id'] = $entity->page_id;
		}
		else
		{
			throw new \InvalidArgumentException("Entity must be wiki page");
		}

		return $extraContext;
	}
}