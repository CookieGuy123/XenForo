<?php

namespace EWR\Carta;

use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;
	
	public function installStep1()
	{
		$this->schemaManager()->createTable('ewr_carta_cache', function(Create $table)
		{
			$table->checkExists(true);
			$table->addColumn('page_id',				'int', 100);
			$table->addColumn('cache_date',				'int', 10);
			$table->addColumn('cache_content',			'mediumtext');
			$table->addPrimaryKey('page_id');
		});
		
		$this->schemaManager()->createTable('ewr_carta_history', function(Create $table)
		{
			$table->checkExists(true);
			$table->addColumn('page_id',				'int', 100);
			$table->addColumn('user_id',				'int', 10);
			$table->addColumn('username',				'varchar', 100);
			$table->addColumn('ip_id',					'int', 10);
			$table->addColumn('history_id', 			'int', 10)->autoIncrement();
			$table->addColumn('history_date',			'int', 10);
			$table->addColumn('history_type',			'enum')->values(['bbcode','html','phpfile']);
			$table->addColumn('history_content',		'mediumtext');
			$table->addColumn('history_revert',			'int', 1);
			$table->addPrimaryKey('history_id');
			$table->addKey('page_id');
		});
		
		$this->schemaManager()->createTable('ewr_carta_pages', function(Create $table)
		{
			$table->checkExists(true);
			$table->addColumn('thread_id',				'int', 10);
			$table->addColumn('page_id',				'int', 100)->autoIncrement();
			$table->addColumn('page_slug',				'varchar', 100);
			$table->addColumn('page_name',				'varchar', 100);
			$table->addColumn('page_date',				'int', 10);
			$table->addColumn('page_type',				'enum')->values(['bbcode','html','phpfile']);
			$table->addColumn('page_content',			'mediumtext');
			$table->addColumn('page_views',				'int', 10);
			$table->addColumn('page_likes',				'int', 10);
			$table->addColumn('page_like_users',		'blob');
			$table->addColumn('page_options',			'blob');
			$table->addColumn('page_index',				'int', 10);
			$table->addColumn('page_family',			'int', 10);
			$table->addColumn('page_left',				'int', 10);
			$table->addColumn('page_depth',				'int', 10);
			$table->addColumn('page_embed',				'blob')->nullable();
			$table->addPrimaryKey('page_id');
			$table->addUniqueKey('page_slug');
			$table->addKey('page_index');
		});
		
		$this->schemaManager()->createTable('ewr_carta_templates', function(Create $table)
		{
			$table->checkExists(true);
			$table->addColumn('template_id',			'int', 100)->autoIncrement();
			$table->addColumn('template_slug',			'varchar', 100);
			$table->addColumn('template_name',			'varchar', 100);
			$table->addColumn('template_content',		'mediumtext');
			$table->addPrimaryKey('template_id');
			$table->addUniqueKey('template_slug');
		});
		
		$this->schemaManager()->createTable('ewr_carta_watch', function(Create $table)
		{
			$table->checkExists(true);
			$table->addColumn('user_id',				'int', 10);
			$table->addColumn('page_id',				'int', 10);
			$table->addColumn('email_subscribe',		'tinyint', 3)->setDefault(0);
			$table->addPrimaryKey(['user_id', 'page_id']);
			$table->addKey(['page_id', 'email_subscribe']);
		});
	}
	
	public function uninstallStep1()
	{
		$this->schemaManager()->dropTable('ewr_carta_pages');
	}
	
	public function upgrade2000Step1()
	{
		$this->installStep1();
	}
}