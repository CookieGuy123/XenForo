<?php

namespace EWR\Carta\Admin\Controller;

use XF\Mvc\ParameterBag;

class Index extends \XF\Admin\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		$this->assertAdminPermission('EWRcarta');
	}
	
	public function actionIndex(ParameterBag $params)
	{
		return $this->view('EWR\Carta:Index', 'EWRcarta_index');
	}
	
	public function actionCache()
	{
		if ($this->isPost())
		{
			\XF::db()->emptyTable('ewr_carta_cache');
			return $this->redirect($this->buildLink('ewr-carta'));
		}
		
		return $this->view('EWR\Carta:Cache', 'EWRcarta_cache');
	}
}