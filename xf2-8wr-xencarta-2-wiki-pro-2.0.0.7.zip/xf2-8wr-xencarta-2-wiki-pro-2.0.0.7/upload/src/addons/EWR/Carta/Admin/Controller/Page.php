<?php

namespace EWR\Carta\Admin\Controller;

use XF\Mvc\ParameterBag;

class Page extends \XF\Admin\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		$this->assertAdminPermission('EWRcarta');
	}
	
	public function actionIndex(ParameterBag $params)
	{
		$page = $this->filterPage();
		$perPage = 100;
		
		$entries = $this->getPageRepo()->findPage()
			->limitByPage($page, $perPage);

		$filter = $this->filter('_xfFilter', [
			'text' => 'str',
			'prefix' => 'bool'
		]);
		if (strlen($filter['text']))
		{
			$entries->searchTitle($filter['text'], $filter['prefix']);
		}
		
		$viewParams = [
			'wikis' => $entries->fetch(),
			'total' => $entries->total(),
			'page' => $page,
			'perPage' => $perPage,
			'filter' => $filter['text'],
		];
		
		return $this->view('EWR\Carta:Page\List', 'EWRcarta_page_list', $viewParams);
	}
	
	public function actionEdit(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_id, ['Thread']);
		
		$attachmentRepo = $this->repository('XF:Attachment');
		$attachmentData = $attachmentRepo->getEditorData('ewr_carta_page', $wiki);
		
		$viewParams = [
			'wiki' => $wiki,
			'wikis' => $this->getPageRepo()->findPage()
				->where('page_depth', '<=', $this->options()->EWRcarta_parents)
				->fetch(),
			'groups' => $this->finder('XF:UserGroup')->order('title')
				->where('user_group_id', '!=', !empty($wiki->page_options['groups']) ? $wiki->page_options['groups'] : [])
				->order('title')
				->fetch(),
			'attachmentData' => $attachmentData,
		];
		
		return $this->view('EWR\Carta:Page\Edit', 'EWRcarta_page_edit', $viewParams);
	}
	
	public function actionSave(ParameterBag $params)
	{
		$this->assertPostOnly();
		
		$wiki = $this->assertPageExists($params->page_id);
		
		$input = $this->filter('page', 'array');
		$input['page_content'] = $this->plugin('XF:Editor')->fromInput('content');
		
		if ($wiki->canManage())
		{
			$old = $wiki->page_options;
			
			$groupIds = $this->filter('groupIds', 'array');
			$userIds = $this->filter('userIds', 'array');
			$newUsers = array_map('trim', explode(',', $this->filter('usernames', 'str')));
			
			$groups = $this->finder('XF:UserGroup')
				->where('user_group_id', $groupIds)
				->fetch();
				
			$users = $this->finder('XF:User')
				->whereOr([
					['username', $newUsers],
					['user_id', $userIds],
				])
				->fetch();
				
			$input['page_options']['groups'] = $groups->pluckNamed('user_group_id');
			$input['page_options']['users'] = $users->pluckNamed('user_id');
		}
		
		$form = $this->formAction();
		$form->basicEntitySave($wiki, $input);
		$form->run();
		
		$hash = $this->filter('attachment_hash', 'str');
		$inserter = $this->service('XF:Attachment\Preparer');
		$associated = $inserter->associateAttachmentsWithContent($hash, 'ewr_carta_page', $wiki->page_id);
		
		if ($wiki->getOption('rebuild'))
		{
			$this->getPageRepo()->rebuildFamilyTree();
		}
		
		$dynamicRedirect = $this->getDynamicRedirect('invalid', false);
		if ($dynamicRedirect == 'invalid')
		{
			$dynamicRedirect = null;
		}

		if ($dynamicRedirect)
		{
			$redirect = $dynamicRedirect;
		}
		else
		{
			$redirect = $this->buildLink('ewr-carta/pages');
		}
		$redirect .= $this->buildLinkHash($wiki->page_id);

		return $this->redirect($redirect);
	}
	
	public function actionModify(ParameterBag $params)
	{
		if ($params->page_id)
		{
			$wiki = $this->assertPageExists($params->page_id);
		}
		else
		{
			$wiki = $this->em()->create('EWR\Carta:Page');
		}
		
		if ($this->isPost())
		{
			$input = $this->filter('page', 'array');
			
			if (!$wiki->page_content)
			{
				$input['page_content'] = \XF::phrase('EWRcarta_new_page_default');
				$input['page_options'] = ['sidebar'=>1,'sublist'=>1];
			}
			
			$form = $this->formAction();
			$form->basicEntitySave($wiki, $input);
			$form->run();
			
			return $this->redirect($this->buildLink('ewr-carta/pages').$this->buildLinkHash($wiki->page_id));
		}
		
		$viewParams = [
			'wiki' => $wiki
		];
		
		return $this->view('EWR\Carta:Page\Modify', 'EWRcarta_page_modify', $viewParams);
	}
	
	public function actionDelete(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_id);
		
		if (!$wiki->preDelete())
		{
			return $this->error($wiki->getErrors());
		}

		if ($this->isPost())
		{
			$wiki->delete();
			return $this->redirect($this->buildLink('ewr-carta/pages'));
		}
		else
		{
			$viewParams = [
				'wiki' => $wiki
			];
			return $this->view('EWR\Carta:Page\Delete', 'EWRcarta_page_delete', $viewParams);
		}
	}
	
	protected function assertPageExists($id, $with = null, $phraseKey = null)
	{
		return $this->assertRecordExists('EWR\Carta:Page', $id, $with, $phraseKey);
	}
	
	protected function getPageRepo()
	{
		return $this->repository('EWR\Carta:Page');
	}
}