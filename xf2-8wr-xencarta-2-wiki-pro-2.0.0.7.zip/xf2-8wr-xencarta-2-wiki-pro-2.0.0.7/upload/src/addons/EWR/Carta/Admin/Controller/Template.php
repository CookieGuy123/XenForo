<?php

namespace EWR\Carta\Admin\Controller;

use XF\Mvc\ParameterBag;

class Template extends \XF\Admin\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		$this->assertAdminPermission('EWRcarta');
	}
	
	public function actionIndex(ParameterBag $params)
	{
		$page = $this->filterPage();
		$perPage = 100;
		
		$entries = $this->getTemplateRepo()->findTemplate()
			->limitByPage($page, $perPage);

		$filter = $this->filter('_xfFilter', [
			'text' => 'str',
			'prefix' => 'bool'
		]);
		if (strlen($filter['text']))
		{
			$entries->searchTitle($filter['text'], $filter['prefix']);
		}
		
		$viewParams = [
			'templates' => $entries->fetch(),
			'total' => $entries->total(),
			'page' => $page,
			'perPage' => $perPage,
			'filter' => $filter['text'],
		];
		return $this->view('EWR\Carta:Template\List', 'EWRcarta_template_list', $viewParams);
	}
	
	public function actionEdit(ParameterBag $params)
	{
		$template = $this->assertTemplateExists($params->template_id);
		
		$viewParams = [
			'template' => $template,
		];
		
		return $this->view('EWR\Medio:Template\Edit', 'EWRcarta_template_edit', $viewParams);
	}
	
	public function actionAdd(ParameterBag $params)
	{
		return $this->view('EWR\Medio:Template\Edit', 'EWRcarta_template_edit');
	}
	
	public function actionSave(ParameterBag $params)
	{
		$this->assertPostOnly();
		
		if ($params->template_id)
		{
			$template = $this->assertTemplateExists($params->template_id);
		}
		else
		{
			$template = $this->em()->create('EWR\Carta:Template');
		}
		
		$form = $this->formAction();
		$form->basicEntitySave($template, $this->filter('template', 'array'));
		$form->run();

		$dynamicRedirect = $this->getDynamicRedirect('invalid', false);
		if ($dynamicRedirect == 'invalid')
		{
			$dynamicRedirect = null;
		}

		if ($this->request->exists('exit'))
		{
			if ($dynamicRedirect)
			{
				$redirect = $dynamicRedirect;
			}
			else
			{
				$redirect = $this->buildLink('ewr-carta/templates');
			}
			$redirect .= $this->buildLinkHash($template->template_id);
		}
		else
		{
			$redirect = $this->buildLink('ewr-carta/templates/edit', $template, ['_xfRedirect' => $dynamicRedirect]);
		}

		return $this->redirect($redirect);
	}
	
	public function actionDelete(ParameterBag $params)
	{
		$template = $this->assertTemplateExists($params->template_id);
		
		if (!$template->preDelete())
		{
			return $this->error($template->getErrors());
		}

		if ($this->isPost())
		{
			$template->delete();
			return $this->redirect($this->buildLink('ewr-carta/templates'));
		}
		else
		{
			$viewParams = [
				'template' => $template
			];
			return $this->view('EWR\Carta:Template\Delete', 'EWRcarta_template_delete', $viewParams);
		}
	}
	
	protected function assertTemplateExists($id, $with = null, $phraseKey = null)
	{
		return $this->assertRecordExists('EWR\Carta:Template', $id, $with, $phraseKey);
	}
	
	protected function getTemplateRepo()
	{
		return $this->repository('EWR\Carta:Template');
	}
}