<?php

namespace EWR\Carta\Like;

use XF\Mvc\Entity\Entity;

class Page extends \XF\Like\AbstractHandler
{
	protected $contentCacheFields = [
		'count' => 'page_likes',
		'recent' => 'page_like_users'
	];
	
	public function likesCounted(Entity $entity)
	{
		return true;
	}

	public function getContentUserId(Entity $entity)
	{
		return 0;
	}
}