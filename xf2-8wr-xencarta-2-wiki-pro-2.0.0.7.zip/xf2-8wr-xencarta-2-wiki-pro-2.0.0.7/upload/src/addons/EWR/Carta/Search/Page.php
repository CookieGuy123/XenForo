<?php

namespace EWR\Carta\Search;

use XF\Mvc\Entity\Entity;
use XF\Search\IndexRecord;
use XF\Search\MetadataStructure;

class Page extends \XF\Search\Data\AbstractData
{
	public function getIndexData(Entity $entity)
	{
		$index = IndexRecord::create('ewr_carta_page', $entity->page_id, [
			'title' => $entity->page_name,
			'message' => $entity->page_content,
			'date' => $entity->page_date,
			'metadata' => $this->getMetaData($entity)
		]);

		return $index;
	}

	protected function getMetaData(\EWR\Carta\Entity\Page $entity)
	{
		return [];
	}

	public function setupMetadataStructure(MetadataStructure $structure)
	{
	}

	public function getResultDate(Entity $entity)
	{
		return $entity->page_date;
	}

	public function getTemplateData(Entity $entity, array $options = [])
	{
		return [
			'wiki' => $entity,
			'options' => $options
		];
	}
}