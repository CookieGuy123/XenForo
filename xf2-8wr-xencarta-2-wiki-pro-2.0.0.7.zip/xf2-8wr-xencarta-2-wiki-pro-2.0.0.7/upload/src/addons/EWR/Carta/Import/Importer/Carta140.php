<?php

namespace EWR\Carta\Import\Importer;

use XF\Import\StepState;

class Carta140 extends \XF\Import\Importer\AbstractForumImporter
{
	/**
	 * @var \XF\Db\Mysqli\Adapter
	 */
	protected $sourceDb;

	public static function getListInfo()
	{
		return [
			'target' => '[8WR] XenCarta 2.x.x',
			'source' => '[8WR] XenCarta 1.4.0',
		];
	}

	protected function getBaseConfigDefault()
	{
		return [
			'db' => [
				'host' => '',
				'username' => '',
				'password' => '',
				'dbname' => '',
				'port' => 3306
			],
			'data_dir' => '',
			'internal_data_dir' => ''
		];
	}

	public function validateBaseConfig(array &$baseConfig, array &$errors)
	{
		$fullConfig = array_replace_recursive($this->getBaseConfigDefault(), $baseConfig);
		$missingFields = false;

		if ($fullConfig['db']['host'])
		{
			$validDbConnection = false;

			try
			{
				$db = new \XF\Db\Mysqli\Adapter($fullConfig['db'], false);
				$db->getConnection();
				$validDbConnection = true;
			}
			catch (\XF\Db\Exception $e)
			{
				$errors[] = \XF::phrase('source_database_connection_details_not_correct_x', ['message' => $e->getMessage()]);
			}
		}
		else
		{
			$missingFields = true;
		}

		if ($missingFields)
		{
			$errors[] = \XF::phrase('please_complete_required_fields');
		}

		return $errors ? false : true;
	}

	public function renderBaseConfigOptions(array $vars)
	{
		return $this->app->templater()->renderTemplate('admin:import_config_EWRcarta_carta140', $vars);
	}

	protected function getStepConfigDefault()
	{
		return true;
	}

	public function renderStepConfigOptions(array $vars)
	{
		return false;
	}

	public function validateStepConfig(array $steps, array &$stepConfig, array &$errors)
	{
		return true;
	}

	public function getSteps()
	{
		return [
			'templates' => [
				'title' => \XF::phrase('templates'),
			],
			'pages' => [
				'title' => \XF::phrase('EWRcarta_pages'),
			],
			'history' => [
				'title' => \XF::phrase('history'),
				'depends' => ['pages'],
			],
			'watched' => [
				'title' => \XF::phrase('watched_content'),
				'depends' => ['pages'],
			],
		];
	}

	protected function doInitializeSource()
	{
		$this->sourceDb = new \XF\Db\Mysqli\Adapter(
			$this->baseConfig['db'],
			$this->app->config('fullUnicode')
		);
	}

	// ############################## STEP: TEMPLATES #########################

	public function stepTemplates(StepState $state)
	{
		$templates = $this->sourceDb->fetchAll('
			SELECT *
			FROM EWRcarta_templates
			ORDER BY template_name
		');
		
		$this->app->db->emptyTable('ewr_carta_templates');
		
		foreach ($templates AS $template)
		{
			$import = $this->app->em->create('EWR\Carta:Template');
			$import->bulkSet([
				'template_slug' => $template['template_name'],
				'template_name' => $template['template_name'],
				'template_content' => $template['template_content'],
			], ['forceSet' => true]);
			$import->save();
			
			$state->imported++;
		}

		return $state->complete();
	}

	// ############################## STEP: PAGES #########################

	public function stepPages(StepState $state)
	{
		$pages = $this->sourceDb->fetchAll('
			SELECT *
			FROM EWRcarta_pages
			ORDER BY page_id
		');
		
		$this->app->db->update('xf_attachment', ['content_type' => 'ewr_carta_page'], 'content_type = ?', 'wiki');
		$this->app->db->update('xf_liked_content', ['content_type' => 'ewr_carta_page'], 'content_type = ?', 'wiki');
		$this->app->db->emptyTable('ewr_carta_pages');
		
		foreach ($pages AS $page)
		{
			$options = [
				'parent' => $page['page_parent'],
				'redirect' => $page['page_redirect'],
				'protect' => $page['page_protect'],
				'sidebar' => $page['page_sidebar'],
				'sublist' => $page['page_sublist'],
				'groups' => $page['page_groups'] ? explode(',', $page['page_groups']) : [],
				'users' => $page['page_users'] ? explode(',', $page['page_users']) : [],
			];
			
			$import = $this->app->em->create('EWR\Carta:Page');
			$import->bulkSet([
				'thread_id' => $page['thread_id'],
				'page_id' => $page['page_id'],
				'page_slug' => $page['page_slug'],
				'page_name' => $page['page_name'],
				'page_date' => $page['page_date'],
				'page_type' => $page['page_type'],
				'page_content' => $page['page_content'],
				'page_views' => $page['page_views'],
				'page_likes' => $page['page_likes'],
				'page_like_users' => $page['page_like_users'] ? unserialize($page['page_like_users']) : [],
				'page_options' => $options,
				'page_index' => $page['page_index'],
			], ['forceSet' => true]);
			$import->save();
			
			$state->imported++;
		}
		
		\XF::repository('EWR\Carta:Page')->rebuildFamilyTree();

		return $state->complete();
	}

	// ############################## STEP: HISTORY #########################

	public function getStepEndHistory()
	{
		return $this->sourceDb->fetchOne("SELECT MAX(history_id) FROM EWRcarta_history") ?: 0;
	}

	public function stepHistory(StepState $state, array $stepConfig, $maxTime, $limit = 1000)
	{
		$timer = new \XF\Timer($maxTime);
		
		$histories = $this->sourceDb->fetchAll('
			SELECT *
				FROM EWRcarta_history
			WHERE history_id > ? AND history_id <= ?
			ORDER BY history_id ASC
			LIMIT ?
		', [$state->startAfter, $state->end, $limit]);

		if (!$state->startAfter)
		{
			$this->app->db->update('xf_ip', ['content_type' => 'ewr_carta_history', 'action' => ''], 'content_type = ?', 'wiki');
			$this->app->db->emptyTable('ewr_carta_history');
		}
		
		if (!$histories)
		{
			return $state->complete();
		}
		
		foreach ($histories AS $history)
		{
			$oldId = $history['history_id'];
			$state->startAfter = $oldId;
			
			$import = $this->app->em->create('EWR\Carta:History');
			$import->bulkSet([
				'page_id' => $history['page_id'],
				'user_id' => $history['user_id'],
				'username' => $history['username'],
				'ip_id' => $history['history_ip'],
				'history_id' => $history['history_id'],
				'history_date' => $history['history_date'],
				'history_type' => $history['history_type'],
				'history_content' => $history['history_content'],
				'history_revert' => $history['history_revert'],
			], ['forceSet' => true]);
			$import->save();
			
			$state->imported++;

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}

	// ############################## STEP: WATCHED #########################
	
	public function getStepEndWatched()
	{
		return $this->sourceDb->fetchOne("SELECT COUNT(*) FROM EWRcarta_watch") ?: 0;
	}

	public function stepWatched(StepState $state, array $stepConfig, $maxTime, $limit = 1000)
	{
		$timer = new \XF\Timer($maxTime);
		
		$watches = $this->sourceDb->fetchAll('
			SELECT *
				FROM EWRcarta_watch
			ORDER BY user_id ASC, page_id ASC
			LIMIT ?, ?
		', [$state->startAfter, $limit]);

		if (!$state->startAfter)
		{
			$this->app->db->emptyTable('ewr_carta_watch');
		}
		
		if (!$watches)
		{
			return $state->complete();
		}
		
		foreach ($watches AS $watch)
		{
			$import = $this->app->em->create('EWR\Carta:Watch');
			$import->bulkSet([
				'user_id' => $watch['user_id'],
				'page_id' => $watch['page_id'],
				'email_subscribe' => $watch['email_subscribe'],
			], ['forceSet' => true]);
			$import->save();
			
			$state->imported++;
			$state->startAfter = $state->imported;

			if ($timer->limitExceeded())
			{
				break;
			}
		}

		return $state->resumeIfNeeded();
	}
}