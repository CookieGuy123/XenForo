<?php

namespace EWR\Carta\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class History extends Repository
{
	public function findHistory()
	{
		return $this->finder('EWR\Carta:History')
			->with(['Page','User'])
			->order('history_date', 'DESC');
	}
}