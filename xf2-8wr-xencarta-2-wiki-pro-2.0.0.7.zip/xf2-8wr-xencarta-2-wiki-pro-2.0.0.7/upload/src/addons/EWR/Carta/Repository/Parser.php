<?php

namespace EWR\Carta\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class Parser extends Repository
{
	public function parseContentsFromHTML($page, $html)
	{
		if (!$this->options()->EWRcarta_toc_req) { return $html; }
		
		$pattern = '#\<h(\d+)\>(.*?)\</h\g{1}\>#si';
		$count = preg_match_all($pattern, $html, $matches);
		
		if ($count < $this->options()->EWRcarta_toc_req) { return $html; }

		$router = \XF::app()->router();
		$phrase = \XF::phrase('EWRcarta_top');
		$contents = '';
		
		foreach ($matches[0] AS $key => $match)
		{
			$code = $matches[0][$key];
			$type = $matches[1][$key];
			$name = $matches[2][$key];
			
			$link = $router->buildLink('canonical:ewr-carta', $page);

			$slug = strtolower(trim($name));
			$slug = preg_replace('#[^\w-]#', '-', $slug);
			$slug = preg_replace('#-+#', '-', $slug);
			$slug = trim($slug, '-');
			
			if ($this->options()->EWRcarta_toc_num)
			{
				$slug = ($key+1).'-'.$slug;
			}
			
			$head = "<h$type><span class=\"u-anchorTarget\" id=\"$slug\"></span>$name";
			
			if ($this->options()->EWRcarta_toc_top)
			{
				$head .= " <span class=\"carta-gototop\">(<a href=\"$link#top\">$phrase</a>)</span>";
			}
			
			$head .= "</h$type>";
			$contents .= "<li class=\"carta-h$type\"><a href=\"$link#$slug\">".$matches[2][$key]."</a></li>";
			$html = str_replace($code, $head, $html);
		}

		$contents = '<div class="carta-toc"><h2>'.\XF::phrase('EWRcarta_contents').'</h2><ul>'.$contents.'</ul></div><br/>';

		if (stripos($html, '[TOC]') !== false)
		{
			$html = str_ireplace('[TOC]', $contents, $html);
		}
		else
		{
			$html = preg_replace('#(<h(\d+)>)#i', $contents.'$1', $html, 1);
		}
			
		return $html;
	}

	public function parseTemplatesFromHTML($page, $html)
	{
		$templates = $this->repository('EWR\Carta:Template')->findTemplate()
			->fetch();

		$codePattern = '#\[template=([\w-]+)\](.*?)\[/template\]#si';
		$dataPattern = '#([\w-\s]+)=(.+)#si';
		$parsPattern = '#\[if\s?=\{\{\{(\w+)\}\}\}([!<>=]{1,3})(.*?)\](.*?)\[/if\]#si';
		$elsePattern = '#(.*)\[else\s?/?\](.*)#si';

		if (preg_match_all($codePattern, $html, $matches))
		{
			foreach ($matches[0] AS $key => $match)
			{
				$code = $matches[0][$key];
				$vars = $matches[2][$key];
				$name = strtolower($matches[1][$key]);
			
				if (!empty($templates[$name]))
				{
					$values = array();
					$varMatches = explode("|", $vars);
					$template = $templates[$name]->template_content;

					foreach ($varMatches AS $varMatch)
					{
						if (preg_match($dataPattern, $varMatch, $dataMatch))
						{
							$values[trim($dataMatch[1])] = preg_replace('/<br \/>$/i', "", trim($dataMatch[2]));
						}
					}

					if (preg_match_all($parsPattern, $template, $parsMatches))
					{
						foreach ($parsMatches[0] AS $key => $parsMatch)
						{
							$replace = "";
							$original = $parsMatches[0][$key];
							$condition = trim($parsMatches[2][$key]);
							
							if (!empty($values[$parsMatches[1][$key]]))
							{
								$left = $values[$parsMatches[1][$key]];
								$right = trim($parsMatches[3][$key]);
								$pass = trim($parsMatches[4][$key]);

								if (preg_match($elsePattern, $pass, $elseMatch))
								{
									$pass = trim($elseMatch[1]);
									$fail = trim($elseMatch[2]);
								}
								else
								{
									$fail = "";
								}

								switch ($condition)
								{
									case ">":		$replace = ((int)$left >  (int)$right)	? $pass : $fail;		break;
									case "<":		$replace = ((int)$left <  (int)$right)	? $pass : $fail;		break;
									case "=>":		$replace = ((int)$left >= (int)$right)	? $pass : $fail;		break;
									case "=<":		$replace = ((int)$left <= (int)$right)	? $pass : $fail;		break;
									case "==":		$replace = ((int)$left == (int)$right)	? $pass : $fail;		break;
									case "!=":		$replace = ((int)$left != (int)$right)	? $pass : $fail;		break;
									case "!==":		$replace = ($left !== $right) 			? $pass : $fail;		break;
									case "===":		$replace = ($left === $right)			? $pass : $fail;		break;
									case "=!":		$replace = $left;												break;
								}
							}
							

							$template = str_replace($original, $replace, $template);	
						}
					}

					foreach ($values AS $key => $value)
					{
						$template = str_replace("{{{".$key."}}}", $value, $template);
					}

					$html = str_replace($code."<br />", $code, $html);	
					$html = str_replace($code, $template, $html);
				}
			}
		}

		return $html;
	}

	public function parseLinksFromHTML($page, $html)
	{
		if (!$this->options()->EWRcarta_autolink) { return $html; }
		
		$pages = $this->repository('EWR\Carta:Page')->findPage()
			->where('page_id', '!=', $page->page_id)
			->order('page_name', 'DESC')
			->fetch();
			
		foreach ($pages AS $page)
		{
			$link = \XF::app()->router()->buildLink('ewr-carta', $page);
			$pattern = '#(?!(?:[^<]+>|[^>]+(</a>|</h\d+>|</b>)))\b'.preg_quote($page->page_name, '#').'\b#i';
			$replace = "<a href=\"$link\">".$page->page_name."</a>";

			$html = preg_replace($pattern, $replace, $html, 1);
		}
		
		return $html;
	}

	public function parsePagePHP($file)
	{
		$extension = explode('.', $file);

		if (file_exists($file) && end($extension) == 'php')
		{
			ob_start();
			include_once($file);
			$html = ob_get_contents();
			ob_end_clean();
		}
		else
		{
			$html = 'Could not find PHP file: '.htmlspecialchars($file);
		}

		return $html;
	}
}