<?php

namespace EWR\Carta\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class Page extends Repository
{
	public function findPage()
	{
		return $this->finder('EWR\Carta:Page')
			->order('page_name', 'ASC');
	}
	
	public function rebuildFamilyTree(&$pages = false, $family = false, $parent = 0, &$left = 0, $depth = 0)
	{
		if (!$pages)
		{
			$pages = $this->findPage()->fetch();
		}

		foreach ($pages AS $key => $page)
		{
			$page_parent = !empty($page->page_options['parent']) ? $page->page_options['parent'] : 0;
			
			if (($page_parent == $parent) || ($parent == 0 && empty($page_parent)))
			{
				if (empty($page_parent))
				{
					$family = $page->page_id;
				}
				
				$left++;
				
				$page->bulkSet([
					'page_family' => $family,
					'page_left' => $left,
					'page_depth' => $depth,
				]);
				$page->save();
				
				unset($pages[$key]);
				$this->rebuildFamilyTree($pages, $family, $page->page_id, $left, $depth+1);
			}
		}
	}
}