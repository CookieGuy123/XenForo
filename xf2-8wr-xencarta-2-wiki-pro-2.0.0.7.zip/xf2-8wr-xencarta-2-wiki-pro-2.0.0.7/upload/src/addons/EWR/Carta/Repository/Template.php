<?php

namespace EWR\Carta\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class Template extends Repository
{
	public function findTemplate()
	{
		return $this->finder('EWR\Carta:Template')
			->keyedBy('template_slug')
			->order('template_name');
	}
}