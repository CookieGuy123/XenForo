<?php

namespace EWR\Carta\Repository;

use XF\Mvc\Entity\Repository;

class Watch extends Repository
{
	public function setWatchState(\EWR\Carta\Entity\Page $page, \XF\Entity\User $user, $state)
	{
		if (!$page->page_id || !$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid page or user");
		}

		$watch = $this->em->find('EWR\Carta:Watch', [
			'page_id' => $page->page_id,
			'user_id' => $user->user_id
		]);

		switch ($state)
		{
			case 'watch_email':
			case 'watch_no_email':
			case 'no_email':
				if (!$watch)
				{
					$watch = $this->em->create('EWR\Carta:Watch');
					$watch->page_id = $page->page_id;
					$watch->user_id = $user->user_id;
				}
				$watch->email_subscribe = ($state == 'watch_email');
				try
				{
					$watch->save();
				}
				catch (\XF\Db\DuplicateKeyException $e) {}
				break;

			case 'delete':
			case 'stop':
			case '':
				if ($watch)
				{
					$watch->delete();
				}
				break;

			default:
				throw new \InvalidArgumentException("Unknown state '$state'");
		}
	}

	public function setWatchStateForAll(\XF\Entity\User $user, $state)
	{
		if (!$user->user_id)
		{
			throw new \InvalidArgumentException("Invalid user");
		}

		$db = $this->db();

		switch ($state)
		{
			case 'watch_email':
				return $db->update('ewr_carta_watch', ['email_subscribe' => 1], 'user_id = ?', $user->user_id);

			case 'watch_no_email':
			case 'no_email':
				return $db->update('ewr_carta_watch', ['email_subscribe' => 0], 'user_id = ?', $user->user_id);

			case 'delete':
			case 'stop':
			case '':
				return $db->delete('ewr_carta_watch', 'user_id = ?', $user->user_id);

			default:
				throw new \InvalidArgumentException("Unknown state '$state'");
		}
	}

	public function isValidWatchState($state)
	{
		switch ($state)
		{
			case 'watch_email':
			case 'watch_no_email':
			case 'no_email':
			case 'delete':
			case 'stop':
			case '':
				return true;

			default:
				return false;
		}
	}
}