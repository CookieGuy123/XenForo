<?php

namespace EWR\Carta\BbCode;

use XF\BbCode\Renderer\AbstractRenderer;

class Wiki
{
    public static function bbcode($tagChildren, $tagOption, $tag, array $options, $renderer)
    {
		$fail = '[wiki]'.htmlentities($tagChildren[0]).'[/wiki]<br/>';
		
		$wiki = \XF::repository('EWR\Carta:Page')->findPage()
			->where('page_slug', $tagChildren[0])
			->fetchOne();
		
		if (empty($wiki)) { return $fail; }
		
		return \XF::app()->templater()->renderTemplate('public:EWRcarta_bbcode_page', [
			'wiki' => $wiki,
		]);
	}
}