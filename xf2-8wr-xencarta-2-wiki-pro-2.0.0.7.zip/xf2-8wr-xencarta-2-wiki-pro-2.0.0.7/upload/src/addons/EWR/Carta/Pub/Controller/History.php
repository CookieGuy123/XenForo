<?php

namespace EWR\Carta\Pub\Controller;

use XF\Mvc\ParameterBag;

class History extends \XF\Pub\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		if (!\XF::visitor()->hasPermission('EWRcarta', 'viewHistory'))
		{
			throw $this->exception($this->noPermission());
		}
	}
	
	public function actionIndex(ParameterBag $params)
	{
		$history = $this->assertHistoryExists($params->history_id);

		$viewParams = [
			'history' => $history
		];
		
		return $this->view('EWR\Carta:History\View', 'EWRcarta_history_view', $viewParams);
	}
	
	public function actionIp(ParameterBag $params)
	{
		if (!\XF::visitor()->canViewIps())
		{
			throw $this->exception($this->noPermission());
		}
		
		$history = $this->assertHistoryExists($params->history_id, ['Page']);
		
		$breadcrumbs = [
			[
				'href' => $this->buildLink('ewr-carta'),
				'value' => \XF::phrase('EWRcarta_wiki')
			],[
				'href' => $this->buildLink('ewr-carta', $history->Page),
				'value' => $history->Page->page_name
			],
		];
			
		$ipPlugin = $this->plugin('XF:Ip');
		return $ipPlugin->actionIp($history, $breadcrumbs);
	}
	
	public function actionCompare(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($this->filter('page', 'str'));
		
		$ids = [
			'old' => $this->filter('old', 'uint'),
			'new' => $this->filter('new', 'uint')
		];
		
		$histories = $this->getHistoryRepo()->findHistory()
			->where('history_id', $ids)
			->where('page_id', $wiki->page_id)
			->fetch();
		
		$oldText = isset($histories[$ids['old']]) ? $histories[$ids['old']]['history_content'] : '';
		$newText = isset($histories[$ids['new']]) ? $histories[$ids['new']]['history_content'] : $wiki->page_content;
		
		$diff = new \XF\Diff();
		$diffs = $diff->findDifferences($oldText, $newText);
		
		$viewParams = [
			'wiki' => $wiki,
			'diffs' => $diffs
		];
		
		return $this->view('EWR\Carta:History\Compare', 'EWRcarta_history_compare', $viewParams);
	}
	
	public function actionRevert(ParameterBag $params)
	{
		$this->assertPostOnly();
		
		$history = $this->assertHistoryExists($params->history_id, ['Page']);
		
		if (!$history->Page->canEdit())
		{
			throw $this->exception($this->noPermission());
		}
		
		$wiki = $history->Page;
		$wiki->page_content = $history->history_content;
		$wiki->setOption('revert', $history->history_id);
		$wiki->save();
		
		return $this->redirect($this->buildLink('ewr-carta', $wiki));
	}
	
	protected function assertHistoryExists($id, $with = null, $phraseKey = null)
	{
		return $this->assertRecordExists('EWR\Carta:History', $id, $with, $phraseKey);
	}
	
	protected function assertPageExists($id, $with = null, $phraseKey = null)
	{
		return $this->assertRecordExists('EWR\Carta:Page', $id, $with, $phraseKey);
	}
	
	protected function getHistoryRepo()
	{
		return $this->repository('EWR\Carta:History');
	}
	
	protected function getPageRepo()
	{
		return $this->repository('EWR\Carta:Page');
	}
	
	protected function getTemplateRepo()
	{
		return $this->repository('EWR\Carta:Template');
	}

	public static function getActivityDetails(array $activities)
	{
		return \XF::phrase('EWRcarta_viewing_wiki_page');
	}
}