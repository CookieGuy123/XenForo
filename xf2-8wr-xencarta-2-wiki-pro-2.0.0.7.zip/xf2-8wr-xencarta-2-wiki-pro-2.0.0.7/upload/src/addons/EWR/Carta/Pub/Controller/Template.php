<?php

namespace EWR\Carta\Pub\Controller;

use XF\Mvc\ParameterBag;

class Template extends \XF\Pub\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		if (!\XF::visitor()->hasPermission('EWRcarta', 'viewHistory'))
		{
			throw $this->exception($this->noPermission());
		}
	}
	
	public function actionIndex(ParameterBag $params)
	{
		if ($params->template_slug)
		{
			return $this->rerouteController(__CLASS__, 'template', $params);
		}
		
		$entries = $this->getTemplateRepo()->findTemplate();
		
		$viewParams = [
			'templates' => $entries->fetch(),
			'total' => $entries->total(),
		];
		
		return $this->view('EWR\Carta:Special\Templates', 'EWRcarta_special_templates', $viewParams);
	}
	
	public function actionTemplate(ParameterBag $params)
	{
		$template = $this->assertTemplateExists($params->template_slug);

		$viewParams = [
			'template' => $template
		];
		
		return $this->view('EWR\Carta:Template\View', 'EWRcarta_template_view', $viewParams);
	}
	
	protected function assertTemplateExists($id, $with = null, $phraseKey = null)
	{
		$record = $this->finder('EWR\Carta:Template')
			->where('template_slug', $id)
			->fetchOne();
		
		if (!$record)
		{
			throw $this->exception(
				$this->notFound(\XF::phrase('requested_page_not_found'))
			);
		}
		
		return $record;
	}
	
	protected function getTemplateRepo()
	{
		return $this->repository('EWR\Carta:Template');
	}

	public static function getActivityDetails(array $activities)
	{
		return \XF::phrase('EWRcarta_viewing_wiki_page');
	}
}