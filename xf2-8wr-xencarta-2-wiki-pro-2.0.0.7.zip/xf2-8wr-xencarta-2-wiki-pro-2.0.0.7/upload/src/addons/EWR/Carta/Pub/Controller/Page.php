<?php

namespace EWR\Carta\Pub\Controller;

use XF\Mvc\ParameterBag;

class Page extends \XF\Pub\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		if (!\XF::visitor()->hasPermission('EWRcarta', 'viewWiki'))
		{
			throw $this->exception($this->noPermission());
		}
	}
	
	public function actionIndex(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug, ['Thread']);
		$redirect = $this->filter('redirect', 'str');
		$stop = $this->filter('stop', 'uint');
		
		if (empty($stop) && empty($redirect) && !empty($wiki->page_options['redirect']))
		{
			$redirect = $this->getPageRepo()->findPage()
				->where('page_id', $wiki->page_options['redirect'])
				->fetchOne();
			
			if ($redirect)
			{
				return $this->redirect($this->buildLink('ewr-carta', $redirect, ['redirect'=>$wiki->page_slug]));
			}
		}
		elseif ($redirect)
		{
			$redirect = $this->getPageRepo()->findPage()
				->where('page_slug', $redirect)
				->fetchOne();
		}
		
		$attachments = $this->finder('XF:Attachment')
			->where('content_type', 'ewr_carta_page')
			->where('content_id', $wiki->page_id)
			->order('attach_date')
			->fetch();
		
		$wiki->hydrateRelation('Attachments', \XF::em()->getBasicCollection($attachments->toArray()));
		
		$viewParams = [
			'wiki' => $wiki,
			'redirect' => $redirect,
		];
		
		if (!empty($wiki->page_options['sidebar']))
		{
			$viewParams['index'] = $this->finder('EWR\Carta:Page')
				->where('page_index', '>', 0)
				->order('page_index', 'ASC')
				->fetch();
		}
		
		$wiki->fastUpdate('page_views', $wiki->page_views + 1);
		return $this->view('EWR\Carta:Page\View', 'EWRcarta_page_view', $viewParams);
	}
	
	public function actionHistory(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug);
		
		$entries = $this->getHistoryRepo()->findHistory()
			->where('page_id', $wiki->page_id)
			->limit($this->options()->EWRcarta_history_perpage);
		
		$viewParams = [
			'wiki' => $wiki,
			'histories' => $entries->fetchRawEntities(),
		];
		
		return $this->view('EWR\Carta:Page\History', 'EWRcarta_page_history', $viewParams);
	}
	
	public function actionEdit(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug, ['Thread']);
		
		if (!$wiki->canEdit())
		{
			throw $this->exception($this->noPermission());
		}
		
		if ($wiki->canUploadAndManageAttachments())
		{
			$attachmentRepo = $this->repository('XF:Attachment');
			$attachmentData = $attachmentRepo->getEditorData('ewr_carta_page', $wiki);
		}
		else
		{
			$attachmentData = null;
		}
		
		$viewParams = [
			'wiki' => $wiki,
			'wikis' => $this->getPageRepo()->findPage()
				->where('page_depth', '<=', $this->options()->EWRcarta_parents)
				->fetch(),
			'groups' => $this->finder('XF:UserGroup')->order('title')
				->where('user_group_id', '!=', !empty($wiki->page_options['groups']) ? $wiki->page_options['groups'] : [])
				->order('title')
				->fetch(),
			'attachmentData' => $attachmentData,
		];
		
		return $this->view('EWR\Medio:Page\Edit', 'EWRcarta_page_edit', $viewParams);
	}

	public function actionPreview(ParameterBag $params)
	{
		$this->assertPostOnly();
		
		$wiki = $this->assertPageExists($params->page_slug);
		
		if (!$wiki->canEdit() || $wiki->page_type != 'bbcode')
		{
			throw $this->exception($this->noPermission());
		}
		
		$wiki->page_content = $this->plugin('XF:Editor')->fromInput('content');
		$attachments = null;

		$tempHash = $this->filter('attachment_hash', 'str');
		if ($tempHash && $wiki->canUploadAndManageAttachments())
		{
			$attachRepo = $this->repository('XF:Attachment');
			$attachments = $attachRepo->findAttachmentsByTempHash($tempHash)->fetch();
		}

		return $this->plugin('XF:BbCodePreview')->actionPreview($wiki->page_content, 'ewr_carta_page', null, $attachments);
	}
	
	public function actionSave(ParameterBag $params)
	{
		$this->assertPostOnly();
		
		$wiki = $this->assertPageExists($params->page_slug);
		
		if (!$wiki->canEdit())
		{
			throw $this->exception($this->noPermission());
		}
		
		$input = $this->filter('page', 'array');
		$input['page_content'] = $this->plugin('XF:Editor')->fromInput('content');
		
		if ($wiki->canManage())
		{
			$groupIds = $this->filter('groupIds', 'array');
			$userIds = $this->filter('userIds', 'array');
			$newUsers = array_map('trim', explode(',', $this->filter('usernames', 'str')));
			
			$groups = $this->finder('XF:UserGroup')
				->where('user_group_id', $groupIds)
				->fetch();
				
			$users = $this->finder('XF:User')
				->whereOr([
					['username', $newUsers],
					['user_id', $userIds],
				])
				->fetch();
				
			$input['page_options']['groups'] = $groups->pluckNamed('user_group_id');
			$input['page_options']['users'] = $users->pluckNamed('user_id');
		}
		
		$form = $this->formAction();
		$form->basicEntitySave($wiki, $input);
		$form->run();
		
		$hash = $this->filter('attachment_hash', 'str');
		if ($hash && $wiki->canUploadAndManageAttachments())
		{
			$inserter = $this->service('XF:Attachment\Preparer');
			$associated = $inserter->associateAttachmentsWithContent($hash, 'ewr_carta_page', $wiki->page_id);
		}
		
		if ($wiki->getOption('rebuild'))
		{
			$this->getPageRepo()->rebuildFamilyTree();
		}
		
		return $this->redirect($this->buildLink('ewr-carta', $wiki));
	}
	
	public function actionThread(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug, ['Thread']);
		
		if ($wiki->Thread)
		{
			return $this->redirect($this->buildLink('threads', $wiki->Thread));
		}
		
		if ($this->isPost())
		{
			$visitor = \XF::visitor();
			$forum = $this->assertViewableForum($this->filter('node_id', 'uint'));
			
			$creator = $this->service('XF:Thread\Creator', $forum);
			$creator->setContent($wiki->page_name, '[wiki=short]'.$wiki->page_slug.'[/wiki]');
				
			$prefixId = $this->filter('prefix_id', 'uint');
			if ($prefixId && $forum->isPrefixUsable($prefixId))
			{
				$creator->setPrefix($prefixId);
			}
			
			if (!$creator->validate($errors))
			{
				return $this->error($errors);
			}
			
			$thread = $creator->save();
			$wiki->thread_id = $thread->thread_id;
			$wiki->save();
			
			if ($thread->canWatch())
			{
				$this->repository('XF:ThreadWatch')->autoWatchThread($thread, $visitor, true);
			}
			
			if ($visitor->user_id)
			{
				$this->getThreadRepo()->markThreadReadByVisitor($thread, $thread->post_date);

				if ($thread->discussion_state == 'moderated')
				{
					$this->session()->setHasContentPendingApproval();
				}
			}
			
			return $this->redirect($this->buildLink('threads', $thread));
		}
		
		$forums = $this->finder('XF:Node')
			->where('node_id', $this->options()->EWRcarta_forums)
			->where('node_type_id', 'Forum')
			->fetch();
		
		$viewParams = [
			'wiki' => $wiki,
			'forums' => $forums,
		];
		
		return $this->view('EWR\Carta:Page\Thread', 'EWRcarta_page_thread', $viewParams);
	}

	public function actionLikes(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug);

		$breadcrumbs = [
			[
				'href' => $this->buildLink('ewr-carta'),
				'value' => \XF::phrase('EWRcarta_wiki')
			],[
				'href' => $this->buildLink('ewr-carta', $wiki),
				'value' => $wiki->page_name
			],
		];
		$title = \XF::phrase('EWRcarta_members_who_liked_x', ['title' => $wiki->page_name]);

		$likePlugin = $this->plugin('XF:Like');
		return $likePlugin->actionLikes(
			$wiki,
			['ewr-carta/likes', $wiki],
			$title, $breadcrumbs
		);
	}

	public function actionLike(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug);
		if (!$wiki->canLike($error))
		{
			return $this->noPermission($error);
		}

		$likePlugin = $this->plugin('XF:Like');
		return $likePlugin->actionToggleLike(
			$wiki,
			$this->buildLink('ewr-carta/like', $wiki),
			$this->buildLink('ewr-carta', $wiki),
			$this->buildLink('ewr-carta/likes', $wiki)
		);
	}

	public function actionWatch(ParameterBag $params)
	{
		$wiki = $this->assertPageExists($params->page_slug);
		$visitor = \XF::visitor();
		
		if (!$wiki->canWatch() || !$visitor->user_id)
		{
			return $this->noPermission();
		}

		if ($this->isPost())
		{
			if ($this->filter('stop', 'bool'))
			{
				$newState = 'delete';
			}
			else if ($this->filter('email_subscribe', 'bool'))
			{
				$newState = 'watch_email';
			}
			else
			{
				$newState = 'watch_no_email';
			}

			$this->getWatchRepo()->setWatchState($wiki, $visitor, $newState);

			$redirect = $this->redirect($this->buildLink('ewr-carta', $wiki));
			$redirect->setJsonParam('switchKey', $newState == 'delete' ? 'watch' : 'unwatch');
			return $redirect;
		}
		else
		{
			$viewParams = [
				'wiki' => $wiki,
				'isWatched' => !empty($wiki->Watch[$visitor->user_id]),
			];
			return $this->view('EWR\Carta:Page\Watch', 'EWRcarta_page_watch', $viewParams);
		}
	}
	
	protected function assertPageExists($id, $with = null, $phraseKey = null)
	{
		if (!$id) { $id = 'index'; }
		
		$record = $this->finder('EWR\Carta:Page')
			->where('page_slug', $id)
			->fetchOne();
		
		if (!$record)
		{
			throw $this->exception(
				$this->notFound(\XF::phrase('requested_page_not_found'))
			);
		}
		
		return $record;
	}
	
	protected function assertViewableForum($nodeId)
	{
		$forum = $this->finder('XF:Forum')
			->where('node_id', $nodeId)
			->fetchOne();

		if (!$forum)
		{
			throw $this->exception($this->notFound(\XF::phrase('requested_forum_not_found')));
		}
		
		if (!$forum->canView($error))
		{
			throw $this->exception($this->noPermission($error));
		}

		$this->plugin('XF:Node')->applyNodeContext($forum->Node);

		return $forum;
	}
	
	protected function getHistoryRepo()
	{
		return $this->repository('EWR\Carta:History');
	}
	
	protected function getPageRepo()
	{
		return $this->repository('EWR\Carta:Page');
	}
	
	protected function getTemplateRepo()
	{
		return $this->repository('EWR\Carta:Template');
	}
	
	protected function getThreadRepo()
	{
		return $this->repository('XF:Thread');
	}
	
	protected function getWatchRepo()
	{
		return $this->repository('EWR\Carta:Watch');
	}

	public static function getActivityDetails(array $activities)
	{
		return self::getActivityDetailsForContent(
			$activities,
			\XF::phrase('EWRcarta_viewing_wiki_page'),
			'page_slug',
			function(array $ids)
			{
				$wikis = \XF::app()->finder('EWR\Carta:Page')
					->where('page_slug', $ids)
					->keyedBy('page_slug')
					->fetch();

				$router = \XF::app()->router('public');
				$data = [];

				foreach ($wikis AS $id => $wiki)
				{
					$data[$id] = [
						'title' => $wiki->page_name,
						'url' => $router->buildLink('ewr-carta', $wiki)
					];
				}

				return $data;
			}
		);
	}
}