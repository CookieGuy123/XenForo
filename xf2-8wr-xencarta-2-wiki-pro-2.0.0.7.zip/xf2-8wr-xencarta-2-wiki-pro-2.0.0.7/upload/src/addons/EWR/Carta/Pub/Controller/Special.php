<?php

namespace EWR\Carta\Pub\Controller;

use XF\Mvc\ParameterBag;

class Special extends \XF\Pub\Controller\AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		if (!\XF::visitor()->hasPermission('EWRcarta', 'viewWiki'))
		{
			throw $this->exception($this->noPermission());
		}
	}
	
	public function actionIndex(ParameterBag $params)
	{
		return $this->redirect($this->buildLink('ewr-carta'));
	}
	
	public function actionPages(ParameterBag $params)
	{
		$entries = $this->finder('EWR\Carta:Page')
			->order('page_left', 'ASC');
		
		$wikis = [];
		foreach ($entries->fetch() AS $wiki)
		{
			if (empty($wiki->page_options['parent']) || empty($section))
			{
				$section = strtoupper($wiki->page_name)[0];
			}
			
			$wikis[$section][] = $wiki;
		}
		
		$viewParams = [
			'wikis' => $wikis,
			'total' => $entries->total(),
		];
		
		return $this->view('EWR\Carta:Special\Pages', 'EWRcarta_special_pages', $viewParams);
	}
	
	public function actionCreate(ParameterBag $params)
	{
		$visitor = \XF::visitor();
		if (!$visitor->hasPermission('EWRcarta', 'createPages'))
		{
			throw $this->exception($this->noPermission());
		}
		
		if ($this->isPost())
		{
			$wiki = $this->em()->create('EWR\Carta:Page');
			$input = $this->filter('page', 'array');
			$input['page_content'] = \XF::phrase('EWRcarta_new_page_default');
			$input['page_options'] = ['sidebar'=>1,'sublist'=>1];
			
			$form = $this->formAction();
			$form->basicEntitySave($wiki, $input);
			$form->run();
			
			return $this->redirect($this->buildLink('ewr-carta', $wiki));
		}
		
		return $this->view('EWR\Carta:Special\Create', 'EWRcarta_special_create');
	}
	
	public function actionActivity(ParameterBag $params)
	{
		$page = max(1, $params->page);
		$perPage = $this->options()->EWRcarta_history_perpage;
		$entries = $this->getHistoryRepo()->findHistory()
			->limitByPage($page, $perPage);
		$total = $entries->total();
		$maxPage = ceil($total / $perPage);
		
		$this->assertCanonicalUrl($this->buildLink('ewr-carta/special/activity', '', ['page' => $page]));
		$this->assertValidPage($page, $perPage, $total, 'ewr-carta/special/activity');
		
		$viewParams = [
			'activity' => $entries->fetch(),
			
			'total' => $total,
			'page' => $page,
			'perPage' => $perPage,
		];
		
		return $this->view('EWR\Carta:Special\Activity', 'EWRcarta_special_activity', $viewParams);
	}
	
	protected function getHistoryRepo()
	{
		return $this->repository('EWR\Carta:History');
	}
	
	protected function getPageRepo()
	{
		return $this->repository('EWR\Carta:Page');
	}
	
	protected function getTemplateRepo()
	{
		return $this->repository('EWR\Carta:Template');
	}

	public static function getActivityDetails(array $activities)
	{
		return \XF::phrase('EWRcarta_viewing_wiki_page');
	}
}