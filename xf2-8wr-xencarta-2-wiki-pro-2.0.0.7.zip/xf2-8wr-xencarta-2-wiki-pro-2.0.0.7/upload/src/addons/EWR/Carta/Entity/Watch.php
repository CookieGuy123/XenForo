<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class Watch extends \XF\Mvc\Entity\Entity
{
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'ewr_carta_watch';
		$structure->shortName = 'EWR\Carta:Watch';
		$structure->primaryKey = ['user_id', 'page_id'];
		$structure->columns = [
			'user_id'				=> ['type' => self::UINT, 'required' => true],
			'page_id'				=> ['type' => self::UINT, 'required' => true],
			'email_subscribe'		=> ['type' => self::BOOL, 'default' => false]
		];
		$structure->getters = [];
		$structure->relations = [
			'Page' => [
				'entity' => 'EWR\Carta:Page',
				'type' => self::TO_ONE,
				'conditions' => 'page_id',
				'primary' => true
			],
			'User' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true
			],
		];

		return $structure;
	}
}