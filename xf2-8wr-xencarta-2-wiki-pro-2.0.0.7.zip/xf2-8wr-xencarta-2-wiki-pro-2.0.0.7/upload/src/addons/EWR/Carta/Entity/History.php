<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class History extends \XF\Mvc\Entity\Entity
{
	public function getSize()
	{
		return strlen($this->history_content);
	}
	
	protected function _preSave()
	{
		if ($this->isInsert())
		{
			$visitor = \XF::visitor();
				
			if (!$this->user_id)
			{
				$this->user_id = $visitor->user_id;
				$this->username = $visitor->username;
			}
			
			if (!$this->history_date)
			{
				$this->history_date = \XF::$time;
			}
		}
	}
	
	protected function _postSave()
	{
		$visitor = \XF::visitor();
		
		if ($this->isInsert() && $visitor->user_id)
		{
			$newsFeedRepo = \XF::repository('XF:NewsFeed');
			$newsFeedRepo->publish('ewr_carta_page', $this->page_id, 'edit', $visitor->user_id, $visitor->username);
			
			$watchers = $this->Page->getUsersWatching();
			foreach ($watchers AS $watcher)
			{
				if ($visitor->user_id != $watcher->user_id)
				{
					$alertRepo = \XF::repository('XF:UserAlert');
					$alertRepo->alertFromUser($watcher->User, $visitor, 'ewr_carta_page', $this->page_id, 'edit', $this->toArray(false));
				}
			}
		}
	}
	
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'ewr_carta_history';
		$structure->shortName = 'EWR\Carta:History';
		$structure->contentType = 'ewr_carta_history';
		$structure->primaryKey = 'history_id';
		$structure->columns = [
			'page_id'				=> ['type' => self::UINT, 'required' => true],
			'user_id'				=> ['type' => self::UINT, 'required' => true],
			'username'				=> ['type' => self::STR, 'required' => true],
			'ip_id'					=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'history_id'			=> ['type' => self::UINT, 'autoIncrement' => true],
			'history_date'			=> ['type' => self::UINT, 'required' => true],
			'history_type'			=> ['type' => self::STR, 'required' => true,
				'allowedValues' => ['bbcode', 'html', 'phpfile']
			],
			'history_content'		=> ['type' => self::STR, 'required' => true],
			'history_revert'		=> ['type' => self::UINT, 'required' => false, 'default' => 0],
		];
		$structure->behaviors = [];
		$structure->getters = [
			'size' => true,
		];
		$structure->relations = [
			'Page' => [
				'entity' => 'EWR\Carta:Page',
				'type' => self::TO_ONE,
				'conditions' => 'page_id',
				'primary' => true,
			],
			'User' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}