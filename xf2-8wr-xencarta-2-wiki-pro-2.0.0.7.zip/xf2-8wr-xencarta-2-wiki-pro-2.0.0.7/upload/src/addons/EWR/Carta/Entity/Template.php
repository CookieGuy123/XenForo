<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class Template extends \XF\Mvc\Entity\Entity
{
	public function getVariables()
	{
		preg_match_all('#{{{([\w]+)}}}#i', $this->template_content, $matches);
		
		$variables = [];
		foreach ($matches[1] AS $variable)
		{
			$variables[$variable] = $variable;
		}
		
		return $variables;
	}
	
	public function getBbCode()
	{
		$variables = $this->getVariables();
		
		$code = "[template=$this->template_slug] \n";
		foreach ($variables AS $variable)
		{
			$code .= "| $variable= \n";
		}
		$code .= "[/template]";
		
		if (count($variables) < 15)
		{
			$code = str_replace("\n", "", $code);
			$code = preg_replace('#\|\s#', '', $code, 1);
		}
		
		return $code;
	}
	
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'ewr_carta_templates';
		$structure->shortName = 'EWR\Carta:Template';
		$structure->primaryKey = 'template_id';
		$structure->columns = [
			'template_id'			=> ['type' => self::UINT, 'autoIncrement' => true],
			'template_slug'			=> ['type' => self::STR, 'required' => true, 'match' => 'alphanumeric_hyphen'],
			'template_name'			=> ['type' => self::STR, 'required' => true],
			'template_content'		=> ['type' => self::STR, 'required' => true],
		];
		$structure->behaviors = [];
		$structure->getters = [
			'variables' => true,
			'bbcode' => true,
		];
		$structure->relations = [];

		return $structure;
	}
}