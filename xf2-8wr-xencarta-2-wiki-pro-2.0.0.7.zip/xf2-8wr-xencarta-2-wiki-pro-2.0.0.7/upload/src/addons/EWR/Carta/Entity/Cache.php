<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class Cache extends \XF\Mvc\Entity\Entity
{
	protected function _preSave()
	{
		$this->cache_date = \XF::$time;
	}
	
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'ewr_carta_cache';
		$structure->shortName = 'EWR\Carta:Cache';
		$structure->primaryKey = 'page_id';
		$structure->columns = [
			'page_id'				=> ['type' => self::UINT, 'required' => true],
			'cache_date'			=> ['type' => self::UINT, 'required' => true],
			'cache_content'			=> ['type' => self::STR, 'required' => true],
		];
		$structure->behaviors = [];
		$structure->getters = [];
		$structure->relations = [];

		return $structure;
	}
}