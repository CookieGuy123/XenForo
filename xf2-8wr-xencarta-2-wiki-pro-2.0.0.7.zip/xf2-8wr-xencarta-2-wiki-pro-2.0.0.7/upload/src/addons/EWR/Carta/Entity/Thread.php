<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class Thread extends XFCP_Thread
{
	public static function getStructure(Structure $structure)
	{
		$parent = parent::getStructure($structure);
		
		$structure->relations['CartaPage'] = [
			'entity' => 'EWR\Carta:Page',
			'type' => self::TO_ONE,
			'conditions' => 'thread_id',
			'key' => 'page_id',
		];
		
		return $parent;
	}
}