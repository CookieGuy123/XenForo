<?php

namespace EWR\Carta\Entity;

use XF\Mvc\Entity\Structure;

class Page extends \XF\Mvc\Entity\Entity
{
	public function canView(&$error = null)
	{
		$visitor = \XF::visitor();
		
		return ($visitor->hasPermission('EWRcarta', 'viewWiki'));
	}
	
	public function canViewAttachments(&$error = null)
	{
		$visitor = \XF::visitor();
		
		return ($visitor->hasPermission('EWRcarta', 'viewAttachments'));
	}
	
	public function canEdit(&$error = null)
	{
		$visitor = \XF::visitor();
		
		if ($visitor->user_id)
		{
			if ($this->getProtected())
			{
				if ($visitor->hasPermission('EWRcarta', 'managePages')) { return true; }
				if (in_array($visitor->user_id, $this->page_options['users'])) { return true; }
				
				foreach ($this->page_options['groups'] AS $groupId)
				{
					if ($visitor->isMemberOf($groupId)) { return true; }
				}
			}
			else
			{
				if ($visitor->hasPermission('EWRcarta', 'editPages')) { return true; }
			}
		}
		
		return false;
	}
	
	public function canManage(&$error = null)
	{
		$visitor = \XF::visitor();
		
		return ($visitor->user_id && $visitor->hasPermission('EWRcarta', 'managePages'));
	}

	public function canUploadAndManageAttachments()
	{
		$visitor = \XF::visitor();

		return ($visitor->user_id && $visitor->hasPermission('EWRcarta', 'manageAttachments'));
	}
	
	public function canLike(&$error = null)
	{
		$visitor = \XF::visitor();

		return ($visitor->user_id && $visitor->hasPermission('EWRcarta', 'likePages'));
	}

	public function canWatch(&$error = null)
	{
		return \XF::visitor()->user_id ? true : false;
	}

	public function isLiked()
	{
		$visitor = \XF::visitor();
		if (!$visitor->user_id)
		{
			return false;
		}

		return isset($this->Likes[$visitor->user_id]);
	}

	public function isAttachmentEmbedded($attachmentId)
	{
		if (!$this->page_embed)
		{
			return false;
		}

		if ($attachmentId instanceof \XF\Entity\Attachment)
		{
			$attachmentId = $attachmentId->attachment_id;
		}

		return in_array($attachmentId, $this->page_embed);
		
		
		return preg_match('#\[attach.*?\]'.$attachmentId.'\[/attach\]#i', $this->page_content);
	}
	
	public function getProtected()
	{
		if (!empty($this->page_options['protect']) || $this->page_type != 'bbcode')
		{
			return true;
		}
		
		return false;
	}
	
	public function getParsed()
	{
		$parserRepo = \XF::repository('EWR\Carta:Parser');
		
		if ($this->page_type == 'phpfile')
		{
			return $parserRepo->parsePagePHP($this->page_content);
		}
		
		if (\XF::options()->EWRcarta_cache)
		{
			if ($this->Cache)
			{
				if ($this->Cache->cache_date > (\XF::$time - (86400 * \XF::options()->EWRcarta_cache)))
				{
					return $this->Cache->cache_content;
				}
				
				$cache = $this->Cache;
			}
			else
			{
				$cache = $this->em()->create('EWR\Carta:Cache');
				$cache->page_id = $this->page_id;
			}
		}
		
		$html = \XF::app()->bbCode()->render($this->page_content, 'html', 'ewr_carta_page', $this,
			$this->getBbCodeRenderOptions($this, 'ewr_carta_page'));
		
		if ($this->page_type == 'html')
		{
			$html = htmlspecialchars_decode($html);
		}
		
		$html = $parserRepo->parseContentsFromHTML($this, $html);
		$html = $parserRepo->parseTemplatesFromHTML($this, $html);
		$html = $parserRepo->parseLinksFromHTML($this, $html);
		
		if (\XF::options()->EWRcarta_cache)
		{
			$cache->cache_content = $html;
			$cache->save(false);
		}
		
		return $html;
	}
	
	public function getGroups()
	{
		return $this->finder('XF:UserGroup')
			->where('user_group_id', $this->page_options['groups'])
			->order('title')
			->fetch();
	}
	
	public function getUsers()
	{
		return $this->finder('XF:User')
			->where('user_id', $this->page_options['users'])
			->order('username')
			->fetch();
	}
	
	public function getFamilytree()
	{
		$breadcrumbs = [];
		$children = [];
		$family = $this->finder('EWR\Carta:Page')
			->where('page_family', $this->page_family)
			->order('page_left', 'ASC')
			->fetch();
		
		if (!empty($this->page_options['sublist']))
		{	
			foreach ($family->toArray() AS $sibling)
			{
				if ($sibling->page_options['parent'] == $this->page_id)
				{
					$children[] = $sibling;
				}
			}
		}
		
		if (!empty($this->page_options['parent']))
		{
			$parent = $this->page_options['parent'];
			
			foreach (array_reverse($family->toArray()) AS $sibling)
			{
				if ($sibling->page_id == $parent)
				{
					array_unshift($breadcrumbs, [
						'href' => $this->app()->router()->buildLink('ewr-carta', $sibling),
						'value' => $sibling->page_name
					]);
					
					if (empty($sibling->page_options['parent']))
					{
						break;
					}
					
					$parent = $sibling->page_options['parent'];
				}
			}
		}
		
		return [
			'family' => $family,
			'children' => $children,
			'breadcrumbs' => $breadcrumbs,
		];
	}
	
	public function getLikes()
	{
		return $this->page_likes;
	}
	
	public function getLikeUsers()
	{
		return $this->page_like_users;
	}
	
	public function getUsersWatching()
	{
		return $this->finder('EWR\Carta:Watch')
			->with('User', true)
			->where('page_id', $this->page_id)
			->keyedBy('user_id')
			->fetch();
	}

	public function getBbCodeRenderOptions($context, $type)
	{
		return [
			'entity' => $this,
			'attachments' => $this->Attachments,
			'viewAttachments' => $this->canViewAttachments(),
			'stopBreakConversion' => $this->page_type == 'html' ? true : false,
		];
	}
	
	protected function _preSave()
	{
		if ($this->isChanged('page_slug'))
		{
			$this->page_slug = strtolower($this->page_slug);
			
			if ($this->page_slug == 'special')
			{
				$this->error(\XF::phraseDeferred('EWRcarta_page_slug_special_is_reserved'));
			}
			
			$exists = $this->finder('EWR\Carta:Page')
				->where('page_slug', $this->page_slug)
				->fetchOne();
			
			if ($exists)
			{
				$this->error(\XF::phraseDeferred('EWRcarta_page_slugs_must_be_unique', ['slug'=>$this->page_slug]));
			}
		}
		
		if ($this->isChanged('page_content') || $this->isChanged('page_type'))
		{
			if (!$this->isInsert() || !$this->page_date)
			{
				$this->page_date = \XF::$time;
			}
			
			if (preg_match_all('#\[attach.*?\](\d+)\[/attach\]#i', $this->page_content, $matches))
			{
				$this->page_embed = $matches[1];
			}
			else
			{
				$this->page_embed = null;
			}
		}
	}
	
	protected function _postSave()
	{
		if ($this->isChanged('page_name') || $this->isChanged('page_options'))
		{
			$this->setOption('rebuild', true);
		}
		
		if ($this->isChanged('page_date'))
		{
			if ($this->Cache)
			{
				$this->Cache->delete();
			}
			
			$visitor = \XF::visitor();
			$history = $this->finder('EWR\Carta:History')
				->where('page_id', $this->page_id)
				->where('history_date', '>', (\XF::$time - 600))
				->order('history_date', 'DESC')
				->fetchOne();
			
			if ($history && $history->user_id == $visitor->user_id && !$history->history_revert)
			{
				$history->bulkSet([
					'history_date' => \XF::$time,
					'history_content' => $this->page_content,
				]);
				$history->save();
			}
			else
			{
				$history = \XF::app()->em->create('EWR\Carta:History');
				$history->bulkSet([
					'page_id' => $this->page_id,
					'history_type' => $this->page_type,
					'history_content' => $this->page_content,
				]);
				
				if ($this->getOption('revert'))
				{
					$history->history_revert = $this->getOption('revert');
				}
				
				$history->save();
				
				$ip = \XF::app()->request()->getIp();
				$ipRepo = \XF::repository('XF:Ip');
				$ipEnt = $ipRepo->logIp($history->user_id, $ip, 'ewr_carta_history', $history->history_id);
				if ($ipEnt)
				{
					$history->fastUpdate('ip_id', $ipEnt->ip_id);
				}
			}
		}
		
		if ($this->Thread)
		{
			if ($this->isChanged('page_slug'))
			{
				$this->Thread->FirstPost->message = '[wiki=short]'.$this->page_slug.'[/wiki]';
				$this->Thread->FirstPost->save();
			}
			
			if ($this->isChanged('page_name'))
			{
				$this->Thread->title = $this->page_name;
				$this->Thread->save();
			}
		}
	}
	
	protected function _postDelete()
	{
		$this->db()->delete('ewr_carta_cache', 'page_id = ?', $this->page_id);
		$this->db()->delete('ewr_carta_history', 'page_id = ?', $this->page_id);
		
		$attachRepo = $this->repository('XF:Attachment');
		$attachRepo->fastDeleteContentAttachments('ewr_carta_page', $this->page_id);
	}
	
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'ewr_carta_pages';
		$structure->shortName = 'EWR\Carta:Page';
		$structure->contentType = 'ewr_carta_page';
		$structure->primaryKey = 'page_id';
		$structure->columns = [
			'thread_id'				=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_id'				=> ['type' => self::UINT, 'autoIncrement' => true],
			'page_slug'				=> ['type' => self::STR, 'required' => true, 'match' => 'alphanumeric_hyphen'],
			'page_name'				=> ['type' => self::STR, 'required' => true],
			'page_date'				=> ['type' => self::UINT, 'required' => true],
			'page_type'				=> ['type' => self::STR, 'required' => true,
				'allowedValues' => ['bbcode', 'html', 'phpfile']
			],
			'page_content'			=> ['type' => self::STR, 'required' => true],
			'page_views'			=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_likes'			=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_like_users'		=> ['type' => self::JSON_ARRAY, 'required' => false, 'default' => []],
			'page_options'			=> ['type' => self::JSON_ARRAY, 'required' => false, 'default' => []],
			'page_index'			=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_family'			=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_left'				=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_depth'			=> ['type' => self::UINT, 'required' => false, 'default' => 0],
			'page_embed'			=> ['type' => self::JSON_ARRAY, 'nullable' => true, 'default' => null]
		];
		$structure->behaviors = [];
		$structure->getters = [
			'protected' => true,
			
			'parsed' => true,
			'groups' => true,
			'users' => true,
			'familytree' => true,
			
			'likes' => true,
			'like_users' => true,
		];
		$structure->relations = [
			'Attachments' => [
				'entity' => 'XF:Attachment',
				'type' => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'ewr_carta_page'],
					['content_id', '=', '$page_id']
				],
				'with' => 'Data',
				'order' => 'attach_date'
			],
			'Cache' => [
				'entity' => 'EWR\Carta:Cache',
				'type' => self::TO_ONE,
				'conditions' => 'page_id',
				'primary' => true,
			],
			'Likes' => [
				'entity' => 'XF:LikedContent',
				'type' => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'ewr_carta_page'],
					['content_id', '=', '$page_id']
				],
				'key' => 'like_user_id',
				'order' => 'like_date'
			],
			'Thread' => [
				'entity' => 'XF:Thread',
				'type' => self::TO_ONE,
				'conditions' => 'thread_id',
				'primary' => true,
				'with' => ['Forum', 'Forum.Node']
			],
			'Watch' => [
				'entity' => 'EWR\Carta:Watch',
				'type' => self::TO_MANY,
				'conditions' => 'page_id',
				'key' => 'user_id'
			],
		];
		$structure->options = [
			'revert' => false,
			'rebuild' => false,
		];

		return $structure;
	}
}