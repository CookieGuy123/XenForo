<?php

namespace EWR\Carta\Alert;

use XF\Mvc\Entity\Entity;

class Page extends \XF\Alert\AbstractHandler
{
	public function canViewContent(Entity $entity, &$error = null)
	{
		return $entity->canView();
	}

	public function getOptOutActions()
	{
		return [
			'edit',
		];
	}

	public function getOptOutDisplayOrder()
	{
		return 1000;
	}
}