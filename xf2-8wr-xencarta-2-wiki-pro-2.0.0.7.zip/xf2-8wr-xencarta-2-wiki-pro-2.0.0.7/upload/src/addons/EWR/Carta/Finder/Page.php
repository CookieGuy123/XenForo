<?php

namespace EWR\Carta\Finder;

use XF\Mvc\Entity\Finder;

class Page extends Finder
{
	public function searchTitle($match, $prefixMatch = false)
	{
		if ($match)
		{
			$this->whereOr(
				[
					$this->expression('CONVERT (%s USING utf8)', 'page_name'),
					'LIKE',
					$this->escapeLike($match, $prefixMatch ? '?%' : '%?%')
				],
				[
					$this->expression('CONVERT (%s USING utf8)', 'page_slug'),
					'LIKE',
					$this->escapeLike($match, $prefixMatch ? '?%' : '%?%')
				]
			);
		}

		return $this;
	}
}