<?php

namespace EWR\Carta\NewsFeed;

use XF\Mvc\Entity\Entity;

class Page extends \XF\NewsFeed\AbstractHandler
{
	public function canViewContent(Entity $entity, &$error = null)
	{
		return $entity->canView();
	}
}