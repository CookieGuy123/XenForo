<?php

namespace EWR\Carta\Widget;

class Index extends \XF\Widget\AbstractWidget
{
	public function render()
	{
		if (!\XF::visitor()->hasPermission('EWRcarta', 'viewWiki'))
		{
			return false;
		}
		
		$options = $this->options;
		$pageRepo = $this->app->repository('EWR\Carta:Page');
		$index = $pageRepo->findPage()
			->where('page_index', '>', 0)
			->order('page_index', 'ASC');
		
		$viewParams = [
			'index' => $index->fetch(),
		];
		
		return $this->renderer('widget_EWRcarta_index', $viewParams);
	}
}