<?php

namespace EWR\Carta\Sitemap;

class Page extends \XF\Sitemap\AbstractHandler
{
	public function getRecords($start)
	{
		$app = $this->app;

		$ids = $this->getIds('ewr_carta_pages', 'page_id', $start);

		$pageFinder = $app->finder('EWR\Carta:Page');
		$pages = $pageFinder
			->where('page_id', $ids)
			->order('page_id')
			->fetch();

		return $pages;
	}

	public function getEntry($record)
	{
		$url = $this->app->router('public')->buildLink('canonical:ewr-carta', $record);
		return \XF\Sitemap\Entry::create($url, [
			'lastmod' => $record->page_date
		]);
	}

	public function isIncluded($record)
	{
		return $record->canView();
	}
}