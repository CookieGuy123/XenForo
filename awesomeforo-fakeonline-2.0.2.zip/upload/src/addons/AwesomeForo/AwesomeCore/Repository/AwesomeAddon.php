<?php


namespace AwesomeForo\AwesomeCore\Repository;
use XF\PrintableException;
use XF\Mvc\Entity\Repository;

class AwesomeAddon extends Repository
{
	public function findAwesomeAddon($addonId)
	{
		return $this->finder('AwesomeForo\AwesomeCore:AwesomeAddon')
			->where('product_id', $addonId)
			->fetchOne();
	}

	public function getAwesomeAddon()
	{
		return $this->finder('AwesomeForo\AwesomeCore:AwesomeAddon')
			->fetch();
	}

	public function getLicenseStatus($addonId)
	{
		return true;
	}

	public function docheckLicense($addOn, $versionId = 0 , $addonId = '')
	{
		$db = $this->db();
		$db->query("CREATE TABLE IF NOT EXISTS `xf_awesomeforo_product` (
				  `product_id` int(11) NOT NULL,
				  `addon_id` varchar(255) NOT NULL,
				  `license_data` BLOB NOT NULL,
				  PRIMARY KEY (`product_id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

		if(!$response = $this->doValidateLicense($addOn, $versionId, $addonId, $error))
		{
			if($error)
			{
			 throw new PrintableException($error); 
			}
		}
	}

	public function doValidateLicense($addOn, $versionId, $addonId  , &$error)
	{ 
		return true;
	}
}

