<?php
namespace AwesomeForo\AwesomeCore;

use XF\Container;
use XF\Template\Templater;

class Listener
{
	public static function templaterSetup(Container $container, Templater &$templater)
	{
		$templater->addFunction('copyright', function(Templater $templater, &$escape)
		{
			return $templater->fnCopyright($templater, $escape) .self::renderAddonBrandingHtml();
		});
		 
	}

	protected static function renderAddonBrandingHtml()
	{
		return;
	} 

	protected static function getAwesomeAddonRepo()
	{
		return \XF::repository('AwesomeForo\AwesomeCore:AwesomeAddon');
	}
}