<?php 
 

namespace AwesomeForo\AwesomeCore\Entity;

use XF\Mvc\Entity\Structure;
use XF\Mvc\Entity\Entity;

class AwesomeAddon extends Entity
{
	public static function getStructure(Structure $structure)
	{
		$options = \XF::options();
		$structure->table = 'xf_awesomeforo_product';
		$structure->shortName = 'AwesomeForo\AwesomeCore:AwesomeAddon';
		$structure->primaryKey = 'product_id';
		$structure->columns = [
			'product_id' =>	['type' => self::UINT, 'required' => true],
			'addon_id' =>	['type' => self::STR, 'required' => true],
			'license_data' =>	['type' => self::STR, 'required' => false, 'default' =>''], 
		];

		return $structure;
	}
}
