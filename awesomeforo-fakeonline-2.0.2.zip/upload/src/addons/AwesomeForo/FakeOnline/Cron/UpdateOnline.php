<?php

namespace AwesomeForo\FakeOnline\Cron;
use XF\Util\Arr;
class UpdateOnline
{ 
    public static function run()
	{
		$app = \XF::app();
		$options = $app->options;
		$fakeFinder = $app->finder('XF:User')
			->where('fake_online', 1)
            ->limit($options->awe_Fake_Limit);
		$fakeUsers = $fakeFinder->fetchColumns('user_id');
		$atoFakeUser =[];
		if($options->awe_Fake_Group)
		{
			$autoFakeFinder = $app->finder('XF:User')
				->where('user_group_id' , $options->awe_Fake_Group)
				->limit($options->awe_Fake_Limit);
			$atoFakeUser = $autoFakeFinder->order($fakeFinder->expression('RAND()'))
				->fetchColumns('user_id');
		}
		$fakeByUserName = $options->awe_fake_user ;
		$fakeByUserName = Arr::stringToArray($fakeByUserName, '#\s*,\s*#');
		/** @var \XF\Repository\User $userRepo */
		$userRepo = $app->repository('XF:User');
		$users = $userRepo->getUsersByNames($fakeByUserName, $notFound);
		$fakeByUserNameID = [];
		foreach ($users as $user) {
			$fakeByUserNameID[] = [
				'user_id'=>$user->user_id
			];
		}
		$allUsers = array_merge($fakeUsers,$atoFakeUser, $fakeByUserNameID);

		$FakeList = [];
		foreach ($allUsers as $fake) {
			foreach ($fake as $id) {
				$FakeList[] =  $id;
			}
		}

		$FakeList = array_unique($FakeList); 

		$threadFinder = $app->finder('XF:Thread')
					->where('discussion_state', 'visible')
					->limit($options->awe_Fake_Limit);
 		$threadIds = $threadFinder->fetchColumns('thread_id');
 		$forumIds = $app->finder('XF:Forum')->fetchColumns('node_id');
 		$userIds = $app->finder('XF:User')->limit(50)->fetchColumns('user_id');
 		$type = [];
 		if($options->fake_type['thread'] == 1 && $threadIds)
		{
	 		$type['thread'] = [
	 			'controler' => 'XF\Pub\Controller\Thread', 'View',
	 			'id' => $threadIds[array_rand($threadIds)]
	 		];
	 	}
	 	if($options->fake_type['forum'] == 1)
		{
		    if($forumIds)
            {
                $type['forum'] = [
                    'controler' => 'XF\Pub\Controller\Forum', 'View',
                    'id' => $forumIds[array_rand($forumIds)]
                ];
            }
            if($threadIds) {
                $type['index'] = [
                    'controler' => 'XF\Pub\Controller\Forum', 'Index',
                    'id' => $threadIds[array_rand($threadIds)]
                ];
            }
 		}
 		if($options->fake_type['inbox'] == 1)
		{
	 		$type['inbox'] = [
	 			'controler' => 'XF\Pub\Controller\Conversation', 'Index',
	 			'id' => [],
	 		]; 
	 	}
 		if($options->fake_type['member'] == 1)
		{
	 		$type['memberlist'] = [
	 			'controler' => 'XF\Pub\Controller\Member', 'Index',
	 			'id' => []
	 		];
	 		$type['member'] = [
	 			'controler' => 'XF\Pub\Controller\Member', 'View',
	 			'id' => $userIds[array_rand($userIds)]
	 		];
	 	}

        /** @var activity $activityRepo */
        $activityRepo =  $app->repository('AwesomeForo\FakeOnline:FakeOnline');
		foreach ($FakeList as $userID) 
		{
			$activity = $type[array_rand($type)];
			$activityRepo->updateSessionActivity(
				$userID, '',
				$activity['controler'], 'View', $activity['id'] , 'valid'
			);
		}
		if($options->awe_fake_guest['enabled'] == 1)
		{
			for($i = 1; $i<=$options->awe_fake_guest['number']; $i++) {
				unset($type['inbox']);
			    $activity = $type[array_rand($type)];
			    $ip = "".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255).".".mt_rand(0,255);
				$activityRepo->updateSessionActivity(
					0, $ip,
					$activity['controler'], 'View', $activity['id'] , 'valid'
				);
			}
		}
		


	} 
}