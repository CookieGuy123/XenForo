<?php

namespace AwesomeForo\FakeOnline\XF\Pub\Controller;
use XF\Mvc\ParameterBag;

class Member extends XFCP_Member
{
	
	public function actionFakeonline(ParameterBag $params)
	{
		$user = $this->assertViewableUser($params->user_id, [], true);

		if ($this->isPost()) 
		{
			if (!$user->canBan($error))
			{
				return $this->error($error);
			}
            $user->fake_online = 1;
            $user->save();
            /** @var \XF\Repository\Thread $threadRepo */
			$activityRepo =  $this->repository('XF:SessionActivity');
			$activityRepo->updateSessionActivity(
				$user->user_id, $this->request->getIp(),
				'XF\Pub\Controller\Thread', 'View', ['thread_id'=>30] , 'valid', ''
			);
			 
            return $this->redirect($this->buildLink('members', $user));
        } 
        else 
        {
        	if (!$user->canBan($error))
			{
				return $this->error($error);
			}
            $viewParams = [
                'user' => $user
            ];

            return $this->view('AwesomeForo\FakeOnline:Fakeonline', 'awe_Fakeonline_confirm', $viewParams);
        }
	}
	public function actionDeletefake(ParameterBag $params)
	{
		$user = $this->assertViewableUser($params->user_id, [], true);

		if ($this->isPost()) 
		{
			if (!$user->canBan($error))
			{
				return $this->error($error);
			}
            $user->fake_online = 0;
            $user->save();
            return $this->redirect($this->buildLink('members', $user));
        } 
        else 
        {
        	if (!$user->canBan($error))
			{
				return $this->error($error);
			}
            $viewParams = [
                'user' => $user
            ];

            return $this->view('AwesomeForo\FakeOnline:Fakeonline', 'awe_Fakeonline_delete', $viewParams);
        }
	}
}