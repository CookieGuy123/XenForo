<?php

namespace AwesomeForo\FakeOnline;

use AwesomeForo\AwesomeCore\AwesomeSetup;
use AwesomeForo\FakeOnline\Core;
use XF\Db\Schema\Create;
use XF\Db\Schema\Alter;

class Setup extends AwesomeSetup
{
    protected $addOnID = Core::PRODUCT_ID;
    protected function getAlters()
    {
        $alters = [];
        $alters['xf_user'] = function(Alter $table) {
            $table->addColumn('fake_online', 'int')->setDefault(0);
        }; 
        return $alters;
    }

}