<?php

namespace AwesomeForo\FakeOnline\Repository;

use XF\Mvc\Entity\Repository;

class FakeOnline extends Repository
{
     public function updateSessionActivity($userId, $ip, $controller, $action, array $params, $viewState)
     {
          $userId = intval($userId);
          $binaryIp = \XF\Util\Ip::convertIpStringToBinary($ip);
          $uniqueKey = ($userId ? $userId : $binaryIp);

          if ($userId)
          {
               $robotKey = '';
          }

          $logParams = [];
          foreach ($params AS $paramKey => $paramValue)
          {
               if (!strlen($paramKey) || !is_scalar($paramValue))
               {
                    continue;
               }

               $logParams[] = "$paramKey=" . urlencode($paramValue);
          }
          $paramList = implode('&', $logParams); 
          $time = \XF::$time - (rand(3, 10) * 60);


          $this->db()->query("
               -- XFDB=noForceAllWrite
               INSERT INTO xf_session_activity
                    (`user_id`, `unique_key`, `ip`, `controller_name`, `controller_action`, `view_state`, `params`, `view_date`)
               VALUES
                    (?, ?, ?, ?, ?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE ip = VALUES(ip),
                    controller_name = VALUES(controller_name),
                    controller_action = VALUES(controller_action),
                    view_state = VALUES(view_state),
                    params = VALUES(params),
                    view_date = VALUES(view_date)
          ", [$userId, $uniqueKey, $binaryIp, $controller, $action, $viewState, $paramList, $time]);
          // TODO: swallow errors if upgrade is pending
     }
}
