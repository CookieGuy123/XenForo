<?php

namespace AwesomeForo\FakeOnline;
class Core
{
    const PRODUCT_ID = 3; 
}
