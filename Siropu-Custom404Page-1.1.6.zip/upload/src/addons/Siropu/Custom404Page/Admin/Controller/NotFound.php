<?php

namespace Siropu\Custom404Page\Admin\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\FormAction;

class NotFound extends \XF\Admin\Controller\AbstractController
{
     public function actionIndex(ParameterBag $params)
     {
          $filter = $this->filter([
               'url'             => 'str',
               'ip'              => 'str',
               'redirect'        => 'bool',
               'order_field'     => 'str',
               'order_direction' => 'str',
          ]);

          $cookieEntires = \XF::app()->request()->getCookie('404NotFoundEntries');
          $cookieEntires = $cookieEntires ? explode(',', $cookieEntires) : null;
          $entries       = $cookieEntires ?: $this->filter('entries', 'array');

          if ($this->isPost() && !empty($entries))
          {
               $action = $this->filter('action', 'str');
               $url    = $this->filter('url', 'str');
               $ids    = implode(',', array_map('intval', $entries));

               switch ($action)
               {
                    case 'save':
                         foreach ($this->filter('redirect_url', 'array') as $id => $url)
                         {
                              if (empty($url))
                              {
                                   continue;
                              }

                              \XF::db()->update('xf_siropu_custom_404_page_not_found', ['redirect_url' => $url], 'entry_id = ?', $id);
                         }
                         break;
                    case 'delete':
                         \XF::db()->delete(
                              'xf_siropu_custom_404_page_not_found',
                              'entry_id IN (' . $ids . ')'
                         );
                         if ($cookieEntires)
                         {
                              \XF::app()->response()->setCookie('404NotFoundEntries', '');
                         }
                         break;
                    case 'redirect':
                         if (!$url)
                         {
                              return $this->message(\XF::phrase('siropu_custom_404_page_redirect_url_required'));
                         }
                         \XF::db()->update(
                              'xf_siropu_custom_404_page_not_found',
                              ['redirect_url' => $url],
                              'entry_id IN (' . $ids . ')'
                         );
                         break;
               }

               return $this->redirect($this->buildLink('404-not-found'));
          }

          $page    = $this->filterPage();
          $perPage = 25;

          if (!in_array($filter['order_field'], ['entry_date', 'last_view_date', 'view_count']))
          {
               $filter['order_field'] = 'entry_date';
          }

          if (!in_array($filter['order_direction'], ['ASC', 'DESC']))
          {
               $filter['order_direction'] = 'DESC';
          }

          $session = \XF::app()->session();

          if ($this->filter('save_order', 'bool'))
          {
               $session->set('siropu404NotFoundOrderField', $filter['order_field']);
               $session->set('siropu404NotFoundOrderDirirection', $filter['order_direction']);
          }

          $filter['order_field']     = $session->get('siropu404NotFoundOrderField') ?: 'entry_date';
          $filter['order_direction'] = $session->get('siropu404NotFoundOrderDirirection') ?: 'DESC';

          $finder = $this->finder('Siropu\Custom404Page:NotFound')
               ->order($filter['order_field'], $filter['order_direction'])
               ->limitByPage($page, $perPage);

          if ($filter['url'])
          {
               if (strpos($filter['url'], '*') !== false)
               {
                    $escapeLike = $finder->escapeLike(str_replace('*', '', $filter['url']), '%?%');
                    $finder->whereOr([['url', 'LIKE', $escapeLike], ['redirect_url', 'LIKE', $escapeLike]]);
               }
               else
               {
                    $finder->whereOr([['url', $filter['url']], ['redirect_url', $filter['url']]]);
               }
          }
          else
          {
               if ($filter['redirect'])
               {
                    $finder->where('redirect_url', '<>', '');
               }
               else
               {
                    $finder->where('redirect_url', '');
               }
          }

          if ($filter['ip'])
          {
               $finder->where('ip', \XF\Util\Ip::convertIpStringToBinary($filter['ip']));
          }

          $viewParams = [
               'entries'    => $finder->fetch(),
               'total'      => $finder->total(),
               'page'       => $page,
               'perPage'    => $perPage,
               'linkParams' => $filter
          ];

          return $this->view('Siropu\Custom404Page:NotFound', 'siropu_custom_404_page_not_found_list', $viewParams);
     }
     public function actionAddRedirect(ParameterBag $params)
     {
          $notFound = $this->assertEntryExists($params->entry_id);

          $viewParams = [
               'notFound' => $notFound
          ];

          return $this->view('Siropu\Custom404Page:NotFound\AddRedirect', 'siropu_custom_404_page_not_found_add_redirect', $viewParams);
     }
     public function actionSave(ParameterBag $params)
     {
          $this->assertPostOnly();
          $notFound = $this->assertEntryExists($params->entry_id);

		$this->entrySaveProcess($notFound)->run();

		return $this->redirect($this->buildLink('404-not-found'));
     }
     public function actionDelete(ParameterBag $params)
     {
          $notFound = $this->assertEntryExists($params->entry_id);
          $plugin   = $this->plugin('XF:Delete');

          return $plugin->actionDelete(
               $notFound,
               $this->buildLink('404-not-found/delete', $notFound),
               $this->buildLink('404-not-found/add-redirect', $notFound),
               $this->buildLink('404-not-found'),
               $notFound->url
          );
     }
     public function actionClearLog()
     {
          if ($this->isPost())
          {
               $action = $this->filter('action', 'str');

               switch ($action)
               {
                    case 'delete_all':
                         \XF::db()->emptyTable('xf_siropu_custom_404_page_not_found');
                         break;
                    case 'no_redirect':
                         \XF::db()->delete('xf_siropu_custom_404_page_not_found', 'redirect_url = ""');
                         break;
                    case 'ip':
                         $ipAddress = \XF\Util\Ip::convertIpStringToBinary($this->filter('ip', 'str'));
                         \XF::db()->delete('xf_siropu_custom_404_page_not_found', 'ip = ?', $ipAddress);
                         break;
               }

               return $this->redirect($this->buildLink('404-not-found'));
          }

          return $this->view('Siropu\Custom404Page:NotFound\ClearLog', 'siropu_custom_404_page_not_found_clear_log');
     }
     protected function entrySaveProcess(\Siropu\Custom404Page\Entity\NotFound $notFound)
	{
          $input = $this->filter([
               'redirect_url' => 'str'
          ]);

          $form = $this->formAction();
          $form->basicEntitySave($notFound, $input);

		return $form;
     }
     protected function assertEntryExists($id, $with = null)
     {
          return $this->assertRecordExists('Siropu\Custom404Page:NotFound', $id, $with, 'requested_log_entry_not_found');
     }
}
