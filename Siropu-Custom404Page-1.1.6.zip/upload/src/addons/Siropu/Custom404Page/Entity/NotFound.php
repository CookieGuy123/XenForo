<?php

namespace Siropu\Custom404Page\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class NotFound extends Entity
{
     public static function getStructure(Structure $structure)
	{
          $structure->table      = 'xf_siropu_custom_404_page_not_found';
          $structure->shortName  = 'Custom404Page:NotFound';
          $structure->primaryKey = 'entry_id';

          $structure->columns = [
               'entry_id'        => ['type' => self::UINT, 'autoIncrement' => true],
               'entry_date'      => ['type' => self::UINT, 'default' => \XF::$time],
               'url'             => ['type' => self::STR, 'match' => 'url', 'required' => true],
               'index_key'       => ['type' => self::STR, 'default' => ''],
               'last_view_date'  => ['type' => self::UINT, 'default' => \XF::$time],
               'redirect_url'    => ['type' => self::STR, 'default' => ''],
               'referrer'        => ['type' => self::JSON_ARRAY, 'default' => []],
               'ip'              => ['type' => self::BINARY, 'maxLength' => 16, 'default' => ''],
               'view_count'      => ['type' => self::UINT, 'default' => 1]
          ];

          return $structure;
     }
     public function setReferrer()
	{
          $referrer = \XF::app()->request()->getReferrer();

          if ($referrer)
          {
               $cache = $this->referrer;
               $cache[] = $referrer;

               $this->referrer = array_unique($cache);
          }
	}
     public function setIp()
     {
          $this->ip = \XF\Util\Ip::convertIpStringToBinary(\XF::app()->request()->getIp(true));
     }
     public function setIndexKey()
     {
          $this->index_key = sha1($this->url);
     }
     protected function _preSave()
	{
          if ($this->isInsert())
          {
               $this->setIndexKey();
          }
	}
}
