<?php

namespace Siropu\Custom404Page\Option;

class Regex extends \XF\Option\AbstractOption
{
	public static function renderOption(\XF\Entity\Option $option, array $htmlParams)
	{
		$choices = $option->option_value;

		return self::getTemplate('admin:siropu_custom_404_page_option_template_regex', $option, $htmlParams, [
			'choices'     => $choices,
			'nextCounter' => count($choices)
		]);
	}
	public static function verifyOption(array &$value)
	{
          foreach ($value AS $key => $val)
		{
			if (empty($val['find']) || empty($val['redirect']) || !\XF\Util\Php::isValidRegex($val['find']))
			{
				unset($value[$key]);
			}
		}

		return true;
	}
}
