<?php

namespace Siropu\Custom404Page\Option;

class ContentTemplate extends \XF\Option\AbstractOption
{
	public static function verifyOption(&$value)
	{
		$template = \XF::em()->findOne('XF:Template', ['title' => 'siropu_custom_404_page_content']);
          $template->template = $value;
          $template->saveIfChanged($saved, false);

		return true;
	}
}
