<?php

namespace Siropu\Custom404Page\Job;

use XF\Job\AbstractRebuildJob;

class Url extends AbstractRebuildJob
{
	protected function getNextIds($start, $batch)
	{
		$db = $this->app->db();

		return $db->fetchAllColumn($db->limit(
			"
				SELECT entry_id
				FROM xf_siropu_custom_404_page_not_found
				WHERE entry_id > ?
                    ORDER BY entry_id
			", $batch
		), $start);
	}
     protected function rebuildById($id)
	{
          /** @var \Siropu\Custom404Page\Entity\NotFound $notFound */
		$notFound = $this->app->em()->find('Siropu\Custom404Page:NotFound', $id);
          $notFound->setIndexKey();
          $notFound->saveIfChanged();
     }
	protected function getStatusType()
	{
		return \XF::phrase('siropu_custom_404_page_rebuild_url_index_key');
	}
}
