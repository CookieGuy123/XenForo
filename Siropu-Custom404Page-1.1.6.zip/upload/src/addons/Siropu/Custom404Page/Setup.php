<?php

namespace Siropu\Custom404Page;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;

	public function installStep1()
	{
		$this->schemaManager()->createTable('xf_siropu_custom_404_page_not_found', function(Create $table)
		{
               $table->engine('MyISAM');

               $table->addColumn('entry_id', 'int')->autoIncrement();
			$table->addColumn('entry_date', 'int')->setDefault(0);
               $table->addColumn('url', 'text');
               $table->addColumn('index_key', 'varchar', 40);
			$table->addColumn('last_view_date', 'int')->setDefault(0);
			$table->addColumn('redirect_url', 'text');
               $table->addColumn('referrer', 'mediumblob');
               $table->addColumn('ip', 'varbinary', 16)->setDefault('');
               $table->addColumn('view_count', 'int')->setDefault(1);
			$table->addFullTextKey('url');
               $table->addFullTextKey('redirect_url');
               $table->addKey('index_key');
			$table->addKey('entry_date');
               $table->addKey('last_view_date');
               $table->addKey('view_count');
		});
	}
     public function upgrade1010070Step1()
	{
          $this->schemaManager()->alterTable('xf_siropu_custom_404_page_not_found', function(Alter $table)
		{
               $table->addColumn('referrer', 'blob');
               $table->addFullTextKey('redirect_url');
               $table->addKey('last_view_date');
               $table->addKey('view_count');
          });
     }
     public function upgrade1010270Step1()
	{
          $this->schemaManager()->alterTable('xf_siropu_custom_404_page_not_found', function(Alter $table)
		{
               $table->addColumn('ip', 'varbinary', 16)->setDefault('');
               $table->addKey('ip');
          });
     }
     public function upgrade1010370Step1()
	{
          $this->schemaManager()->alterTable('xf_siropu_custom_404_page_not_found', function(Alter $table)
		{
               $table->changeColumn('referrer', 'mediumblob');
          });
     }
     public function upgrade1010570Step1()
	{
          $this->schemaManager()->alterTable('xf_siropu_custom_404_page_not_found', function(Alter $table)
		{
               $table->addColumn('index_key', 'varchar', 40);
               $table->addKey('index_key');
          });
     }
	public function uninstallStep1()
	{
		$this->schemaManager()->dropTable('xf_siropu_custom_404_page_not_found');
	}
     public function postUpgrade($previousVersion, array &$stateChanges)
	{
          $template = \XF::em()->findOne('XF:Template', ['title' => 'siropu_custom_404_page_content']);
          $template->template = \XF::options()->siropuCustom404PageContent;
          $template->save(false);

          if ($previousVersion < 1010670)
		{
               $job      = 'Siropu\Custom404Page:Url';
               $uniqueId = 'Rebuild' . $job;
               $id       = \XF::app()->jobManager()->enqueueUnique($uniqueId, $job);
               $router   = \XF::app()->router('admin');

               return \XF::app()->response()->redirect(
                    $router->buildLink('tools/run-job', null, ['only_id' => $id, '_xfRedirect' => $router->buildLink('add-ons')])
               );
          }
     }
}
