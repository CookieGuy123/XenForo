<?php

namespace Siropu\Custom404Page;

use XF\Mvc\Entity\Entity;

class Listener
{
     public static function appPubComplete(\XF\App $app, \XF\Http\Response &$response)
     {
          if ($response->httpCode() == 404)
          {
               $options    = \XF::options();

               $requestUri = $app->request()->getFullRequestUri();
               $requestUri = preg_replace('/(page-[\d]+|\?page=[\d]+)$/', '', $requestUri);

               foreach (array_filter(explode("\n", $options->siropuCustom404IgnoredUrls)) as $ignored)
               {
                    if ($requestUri == $ignored
                         || strpos($ignored, '*')
                              !== false && preg_match('/' . preg_quote(str_replace('*', '', $ignored), '/') . '/', $requestUri))
                    {
                         return;
                    }
               }

               foreach ($options->siropuCustom404PageRegexRedirects as $regex)
               {
                    if (preg_match($regex['find'], $requestUri))
                    {
                         return $response->redirect(preg_replace($regex['find'], $regex['redirect'], $requestUri), 301);
                    }
               }

               $notFound = \XF::em()->findOne('Siropu\Custom404Page:NotFound', ['index_key' => sha1($requestUri)]);

               try
               {
                    if ($notFound)
                    {
                         $notFound->last_view_date = \XF::$time;
                         $notFound->view_count++;
                         $notFound->setReferrer();
                         if (!\XF::visitor()->user_id)
                         {
                              $notFound->setIp();
                         }
                         $notFound->save(false);

                         if ($notFound->redirect_url)
                         {
                              return $response->redirect($notFound->redirect_url, 301);
                         }
                    }
                    else
                    {
                         $notFound = \XF::em()->create('Siropu\Custom404Page:NotFound');
                         $notFound->url = $requestUri;
                         $notFound->setReferrer();
                         $notFound->save(false);
                    }
               }
               catch (\Exception $e) {}

          }
     }
     public static function templaterGlobalData(\XF\App $app, array &$data, $reply)
     {
          if ($reply && !$app->request()->isXhr())
          {
               $data['is404'] = $reply->getResponseCode() == 404;
          }
     }
}
